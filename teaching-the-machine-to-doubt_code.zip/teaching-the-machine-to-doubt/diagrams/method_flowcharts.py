import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from figlib import Fig
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'output'); os.makedirs(OUT, exist_ok=True)
FS = 16
EW = 3.0


class F(Fig):
    def n(self, id, x, y, w, h, label, pal='s1', kind='proc', fs=FS):
        self.node(id, x, y, w, h, label, pal=pal, kind=kind, bold=True, fs=fs)


def save(f, n, name):
    bad = f.check()
    if bad: print('FIT', n, bad)
    f.png(f'{OUT}/figure{n}.png'); f.drawio(f'{OUT}/figure{n}_{name}.drawio', f'Figure {n}')


# ---------------- Figure 2: overall workflow ----------------
f = F(840, 690, ew=EW)
cols = [(10, 'c1', 's1', 'Stage 1\nLearner profiling'),
        (290, 'c2', 's2', 'Stage 2\nFeature optimisation'),
        (570, 'c3', 's3', 'Stage 3\nEvidential prediction')]
for i, (x, cp, _, t) in enumerate(cols):
    f.node(f'C{i}', x, 10, 260, 670, t, pal=cp, kind='cont', fs=17)
Y = [88, 184, 280, 376, 472, 578]
labels = [
    ['Learner records', 'Knowledge, Skill,\nAttitude mapping', 'Domain coherence\nchecks',
     'Outer five-fold\nsplit', 'Fold-wise imputation\nand scaling', 'Domain-tagged\nfeatures'],
    ['Chaotic swarm\ninitialisation', 'Domain-aware\nrepair', 'Random Forest\nfitness',
     'Binary PSO\nupdate', 'Global-best subset;\nrefit forest', 'Selected subset\n(at most 20)'],
    ['Domain\nembeddings', 'Attention over\ndomains', 'Evidential output\n(Dirichlet)',
     'Late fusion with\nRandom Forest', 'Referral rule\n(uncertainty)', 'Band, uncertainty,\nalert or referral'],
]
for c, (x, _, sp, _) in enumerate(cols):
    for r, y in enumerate(Y):
        io = (c == 0 and r == 0) or r == 5
        f.n(f'n{c}{r}', x + 20, y, 220, 62 if r < 5 else 68, labels[c][r], pal='io' if io else sp, kind='io' if io else 'proc')
    for r in range(5):
        if c == 1 and r == 3: continue
        f.edge(f'n{c}{r}', 'b', f'n{c}{r+1}', 't')
f.edge('n13', 'b', 'n14', 't', label='Done', lpos=(420, 455))
f.edge('n13', 'r', 'n11', 'r', pts=[(545, 407), (545, 215)])
f.edge('n05', 'r', 'n10', 'l', pts=[(280, 612), (280, 119)])
f.edge('n15', 'r', 'n20', 'l', pts=[(560, 612), (560, 119)])
save(f, 2, 'workflow')

# ---------------- Figure 3: Stage 1 ----------------
f = F(760, 1010, ew=EW)
f.n('i1', 10, 10, 230, 62, 'Questionnaire\nitems', pal='io', kind='io')
f.n('i2', 265, 10, 230, 62, 'Academic\nrecords', pal='io', kind='io')
f.n('i3', 520, 10, 230, 62, 'Activity and\nbackground data', pal='io', kind='io')
f.n('M', 170, 120, 420, 62, 'Assign each feature to Knowledge,\nSkill, Attitude or background')
f.n('K', 170, 220, 420, 62, 'For each domain: KMO\nand Bartlett\'s test')
f.n('D', 200, 315, 360, 170, 'Questionnaire\ndomain with KMO\nat least 0.70 and\np below 0.05?', pal='dec', kind='dec')
f.n('G', 600, 369, 150, 62, 'Keep block\nfor grouping', pal='grey')
f.n('E', 170, 525, 420, 62, 'Extract factors with eigenvalue\nabove 1; varimax rotation')
f.n('R', 170, 625, 420, 62, 'Keep items with a rotated\nloading of at least 0.40')
f.n('Z', 10, 625, 130, 62, 'Domain\nscores', pal='io', kind='io')
f.n('S', 170, 725, 420, 62, 'Stratified outer\nfive-fold split')
f.n('P', 170, 825, 420, 62, 'In each training fold:\nimpute, then standardise')
f.n('O', 210, 925, 340, 68, 'Domain-tagged feature\nmatrix (to Stage 2)', pal='io', kind='io')
f.edge('i1', 'b', 'M', 't', pts=[(125, 96), (254, 96)], tf=0.2)
f.edge('i2', 'b', 'M', 't')
f.edge('i3', 'b', 'M', 't', pts=[(635, 96), (506, 96)], tf=0.8)
for a, b in [('M', 'K'), ('K', 'D'), ('E', 'R'), ('R', 'S'), ('S', 'P'), ('P', 'O')]:
    f.edge(a, 'b', b, 't')
f.edge('D', 'b', 'E', 't', label='Yes', lpos=(380, 505))
f.edge('D', 'r', 'G', 'l', label='No', lpos=(580, 380))
f.edge('R', 'l', 'Z', 'r')
f.edge('G', 'b', 'S', 'r', pts=[(675, 756)])
save(f, 3, 'stage1')

# ---------------- Figure 4: Stage 2 ----------------
f = F(760, 990, ew=EW)
cx = 470; W = 400; x0 = cx - W / 2
f.n('I', x0 + 40, 10, W - 80, 62, 'Training partition of\none outer fold', pal='io', kind='io')
f.n('C', x0, 110, W, 62, 'Initialise positions and\nvelocities (logistic map)', pal='s2')
f.n('R', x0, 210, W, 62, 'Repair: at least four features\nper domain, at most 20 in total', pal='s2')
f.n('Fi', x0, 310, W, 62, 'Score each subset: Random\nForest, inner three-fold CV', pal='s2')
f.n('B', x0, 410, W, 62, 'Update personal and\nglobal best positions', pal='s2')
f.n('D', cx - 150, 510, 300, 130, 'Iteration limit\nreached?', pal='dec', kind='dec')
f.n('U', 10, 544, 220, 62, 'Update velocities\nand positions', pal='s2')
f.n('G', x0, 680, W, 62, 'Take the global-best subset', pal='s2')
f.n('RF', x0, 780, W, 62, 'Refit a Random Forest\n(100 trees) on the subset', pal='s2')
f.n('O', x0 + 40, 885, W - 80, 68, 'Selected subset and fitted\nforest (to Stage 3)', pal='io', kind='io')
for a, b in [('I', 'C'), ('C', 'R'), ('R', 'Fi'), ('Fi', 'B'), ('B', 'D'), ('G', 'RF'), ('RF', 'O')]:
    f.edge(a, 'b', b, 't')
f.edge('D', 'b', 'G', 't', label='Yes', lpos=(500, 660))
f.edge('D', 'l', 'U', 'r', label='No', lpos=(275, 575))
f.edge('U', 't', 'R', 'l', pts=[(120, 241)])
save(f, 4, 'stage2')

# ---------------- Figure 5: Stage 3 ----------------
f = F(860, 1045, ew=EW)
f.n('I', 260, 10, 340, 62, 'Selected features of\none learner', pal='io', kind='io')
xs = [10, 222, 434, 646]
names = ['Knowledge', 'Skill', 'Attitude', 'Background']
for i, d in enumerate(names):
    pal = 's3' if i < 3 else 'grey'
    f.n(f'b{i}', xs[i], 120, 204, 58, f'{d}\nblock', pal=pal)
    f.n(f'm{i}', xs[i], 220, 204, 58, f'{d}\nembedding', pal=pal)
    f.edge(f'b{i}', 'b', f'm{i}', 't')
    f.edge('I', 'b', f'b{i}', 't', pts=[(430, 96), (xs[i] + 102, 96)])
f.n('A', 240, 340, 380, 62, 'Attention over domains\n(weights sum to one)', pal='s3')
for i in range(4):
    f.edge(f'm{i}', 'b', 'A', 't', pts=[(xs[i] + 102, 310), (430, 310)])
f.n('H', 240, 440, 380, 58, 'Two hidden layers (ReLU)', pal='s3')
f.n('E', 195, 536, 470, 62, 'Evidence for each band\n(Dirichlet distribution)', pal='s3')
f.edge('A', 'b', 'H', 't'); f.edge('H', 'b', 'E', 't')
f.n('P', 10, 660, 190, 62, 'Expected class\nprobabilities', pal='s3')
f.n('RF', 215, 660, 200, 62, 'Random Forest\nprobabilities', pal='s2')
f.n('U', 480, 650, 240, 82, 'Uncertainty measures:\ntotal, aleatoric,\nepistemic, vacuity', pal='dec')
f.edge('E', 'b', 'P', 't', sf=0.2, pts=[(289, 628), (105, 628)])
f.edge('E', 'b', 'U', 't', sf=0.8, tf=(571 - 480) / 240)
f.n('Fu', 30, 807, 310, 66, 'Late fusion: predicted\nband of the learner', pal='io', kind='io')
f.edge('P', 'b', 'Fu', 't', tf=(105 - 30) / 310)
f.edge('RF', 'b', 'Fu', 't', tf=(315 - 30) / 310)
f.n('D', 470, 770, 260, 140, 'Uncertainty\nat or below\nthreshold?', pal='dec', kind='dec')
f.edge('U', 'b', 'D', 't')
f.edge('Fu', 'r', 'D', 'l', label='Band', lpos=(405, 840))
f.n('Y', 485, 960, 230, 68, 'Early-warning\nalert to teacher', pal='io', kind='io')
f.n('N', 725, 960, 130, 68, 'Refer to an\nadvisor', pal='red')
f.edge('D', 'b', 'Y', 't', label='Yes', lpos=(600, 935))
f.edge('D', 'r', 'N', 't', pts=[(790, 840)], label='No', lpos=(790, 900))
save(f, 5, 'stage3')
print('done')
