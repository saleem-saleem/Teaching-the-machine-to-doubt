"""Tiny diagram engine: one layout -> draw.io (.drawio) file + SVG/PNG render that match."""
import html, cairosvg
from xml.sax.saxutils import escape

PAL = {
    's1': ('#DAE8FC', '#6C8EBF'), 's2': ('#FFE6CC', '#D79B00'), 's3': ('#E1D5E7', '#9673A6'),
    'io': ('#D5E8D4', '#82B366'), 'dec': ('#FFF2CC', '#D6B656'), 'red': ('#F8CECC', '#B85450'),
    'grey': ('#F5F5F5', '#666666'), 'c1': ('#F4F8FE', '#6C8EBF'), 'c2': ('#FFF8F0', '#D79B00'), 'c3': ('#F8F4FA', '#9673A6'),
}
FONT = 'Arial'
FS = 13
EDGE = '#262626'

class Fig:
    def __init__(self, w, h, ew=1.6):
        self.W, self.H, self.ew = w, h, ew
        self.nodes = {}; self.order = []; self.edges = []

    def node(self, id, x, y, w, h, label, pal='s1', kind='proc', bold=False, fs=FS, title=None):
        self.nodes[id] = dict(id=id, x=x, y=y, w=w, h=h, label=label, pal=pal, kind=kind, bold=bold, fs=fs, title=title)
        self.order.append(id)

    def anchor(self, id, side, f=0.5):
        n = self.nodes[id]
        if side == 'b': return (n['x'] + n['w'] * f, n['y'] + n['h']), (f, 1)
        if side == 't': return (n['x'] + n['w'] * f, n['y']), (f, 0)
        if side == 'l': return (n['x'], n['y'] + n['h'] * f), (0, f)
        if side == 'r': return (n['x'] + n['w'], n['y'] + n['h'] * f), (1, f)

    def edge(self, s, ss, t, ts, pts=(), sf=0.5, tf=0.5, label=None, lpos=None, dashed=False):
        self.edges.append(dict(s=s, ss=ss, sf=sf, t=t, ts=ts, tf=tf, pts=list(pts), label=label, lpos=lpos, dashed=dashed))

    # ---------------- SVG ----------------
    def svg(self):
        o = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{self.W}" height="{self.H}" viewBox="0 0 {self.W} {self.H}">',
             f'<defs><marker id="ar" viewBox="0 0 10 10" refX="9.5" refY="5" markerWidth="{4.6 if self.ew > 2 else 7}" markerHeight="{4.6 if self.ew > 2 else 7}" orient="auto-start-reverse">'
             f'<path d="M0,0 L10,5 L0,10 z" fill="{EDGE}"/></marker></defs>',
             f'<rect width="{self.W}" height="{self.H}" fill="#FFFFFF"/>']
        for id in self.order:
            n = self.nodes[id]
            if n['kind'] == 'cont': o.append(self._node_svg(n))
        for e in self.edges: o.append(self._edge_svg(e))
        for id in self.order:
            n = self.nodes[id]
            if n['kind'] != 'cont': o.append(self._node_svg(n))
        for e in self.edges:
            if e['label']: o.append(self._elabel_svg(e))
        o.append('</svg>')
        return '\n'.join(o)

    def _text(self, cx, cy, label, fs, bold, anchor='middle'):
        lines = label.split('\n'); lh = fs * 1.25
        y0 = cy - lh * (len(lines) - 1) / 2 + fs * 0.35
        wt = 'bold' if bold else 'normal'
        return ''.join(f'<text x="{cx}" y="{y0 + i * lh:.1f}" font-family="{FONT}, Liberation Sans" font-size="{fs}" font-weight="{wt}" text-anchor="{anchor}" fill="#1A1A1A">{escape(l)}</text>' for i, l in enumerate(lines))

    def _titled(self, n):
        lines = [n['title']] + (n['label'].split('\n') if n['label'] else [])
        fs = n['fs']; lh = fs * 1.3; cx = n['x'] + n['w'] / 2; cy = n['y'] + n['h'] / 2
        y0 = cy - lh * (len(lines) - 1) / 2 + fs * 0.35; out = ''
        for i, l in enumerate(lines):
            wt = 'bold' if i == 0 else 'normal'; sz = fs + 1 if i == 0 else fs
            out += f'<text x="{cx}" y="{y0 + i * lh:.1f}" font-family="{FONT}, Liberation Sans" font-size="{sz}" font-weight="{wt}" text-anchor="middle" fill="#1A1A1A">{escape(l)}</text>'
        return out

    def _node_svg(self, n):
        f, s = PAL[n['pal']]; x, y, w, h = n['x'], n['y'], n['w'], n['h']
        if n.get('title'):
            sw = 2.2 if n['kind'] == 'io' else 1.8
            return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="10" fill="{f}" stroke="{s}" stroke-width="{sw}"/>' + self._titled(n)
        if n['kind'] == 'dec':
            pts = f"{x + w / 2},{y} {x + w},{y + h / 2} {x + w / 2},{y + h} {x},{y + h / 2}"
            return f'<polygon points="{pts}" fill="{f}" stroke="{s}" stroke-width="2.0"/>' + self._text(x + w / 2, y + h / 2, n['label'], n['fs'], n['bold'])
        if n['kind'] == 'cont':
            return (f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="14" fill="{f}" stroke="{s}" stroke-width="1.5" stroke-dasharray="6 4"/>'
                    + self._text(x + w / 2, y + 22, n['label'], n['fs'], True))
        sw = 2.4 if n['kind'] == 'io' else 2.0
        return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="9" fill="{f}" stroke="{s}" stroke-width="{sw}"/>' + self._text(x + w / 2, y + h / 2, n['label'], n['fs'], n['bold'])

    def _path(self, e):
        p0, _ = self.anchor(e['s'], e['ss'], e['sf']); p1, _ = self.anchor(e['t'], e['ts'], e['tf'])
        return [p0] + e['pts'] + [p1]

    def _edge_svg(self, e):
        pts = self._path(e)
        d = ' '.join(f'{x:.1f},{y:.1f}' for x, y in pts)
        da = ' stroke-dasharray="6 4"' if e['dashed'] else ''
        return f'<polyline points="{d}" fill="none" stroke="{EDGE}" stroke-width="{self.ew}"{da} marker-end="url(#ar)" stroke-linejoin="round"/>'

    def _elabel_svg(self, e):
        pts = self._path(e)
        if e['lpos']: x, y = e['lpos']
        else:
            (x0, y0), (x1, y1) = pts[0], pts[1]; x, y = (x0 + x1) / 2, (y0 + y1) / 2
        w = 9.5 * len(e['label']) + 10
        return (f'<rect x="{x - w / 2}" y="{y - 9}" width="{w}" height="18" fill="#FFFFFF"/>'
                + f'<text x="{x}" y="{y + 4.5}" font-family="{FONT}, Liberation Sans" font-size="14" font-weight="bold" text-anchor="middle" fill="#1A1A1A">{escape(e["label"])}</text>')

    def check(self):
        bad = []
        for n in self.nodes.values():
            if n['kind'] == 'cont': continue
            lines = n['label'].split('\n'); cw = n['fs'] * (0.62 if n['bold'] else 0.56)
            avail = n['w'] * (0.62 if n['kind'] == 'dec' else 1) - 18
            for l in lines:
                if len(l) * cw > avail: bad.append((n['id'], l, round(len(l) * cw), round(avail)))
            if len(lines) * n['fs'] * 1.25 > n['h'] * (0.62 if n['kind'] == 'dec' else 1) - 8: bad.append((n['id'], 'height'))
        return bad

    def png(self, path, scale=3):
        cairosvg.svg2png(bytestring=self.svg().encode(), write_to=path, scale=scale)

    # ---------------- draw.io ----------------
    def drawio(self, path, name):
        cells = ['<mxCell id="0"/>', '<mxCell id="1" parent="0"/>']
        def val(s): return escape(s).replace('\n', '&#xa;').replace('"', '&quot;')
        for id in self.order:
            n = self.nodes[id]; f, s = PAL[n['pal']]
            fsty = 'fontStyle=1;' if (n['bold'] or n['kind'] == 'cont') else ''
            if n['kind'] == 'dec':
                st = f'rhombus;whiteSpace=wrap;html=0;fillColor={f};strokeColor={s};strokeWidth=2.0;fontFamily={FONT};fontSize={n["fs"]};{fsty}'
            elif n['kind'] == 'cont':
                st = f'rounded=1;arcSize=4;whiteSpace=wrap;html=0;fillColor={f};strokeColor={s};strokeWidth=1.5;dashed=1;dashPattern=6 4;verticalAlign=top;spacingTop=8;fontFamily={FONT};fontSize={n["fs"]};{fsty}'
            else:
                sw = 2.4 if n['kind'] == 'io' else 2.0
                st = f'rounded=1;arcSize=18;whiteSpace=wrap;html=0;fillColor={f};strokeColor={s};strokeWidth={sw};fontFamily={FONT};fontSize={n["fs"]};{fsty}'
            v = val(n['label'])
            if n.get('title'):
                st = st.replace('html=0', 'html=1')
                v = escape('<b>' + escape(n['title']) + '</b><br>' + '<br>'.join(escape(l) for l in n['label'].split('\n'))).replace('"', '&quot;')
            cells.append(f'<mxCell id="{id}" value="{v}" style="{st}" vertex="1" parent="1"><mxGeometry x="{n["x"]}" y="{n["y"]}" width="{n["w"]}" height="{n["h"]}" as="geometry"/></mxCell>')
        for i, e in enumerate(self.edges):
            _, (ex, ey) = self.anchor(e['s'], e['ss'], e['sf']); _, (nx, ny) = self.anchor(e['t'], e['ts'], e['tf'])
            dash = 'dashed=1;' if e['dashed'] else ''
            st = (f'edgeStyle=none;rounded=0;html=0;endArrow=block;endFill=1;endSize={8 if self.ew > 2 else 6};strokeColor={EDGE};strokeWidth={self.ew};{dash}'
                  f'exitX={ex};exitY={ey};exitDx=0;exitDy=0;entryX={nx};entryY={ny};entryDx=0;entryDy=0;'
                  f'fontFamily={FONT};fontSize=14;fontStyle=1;labelBackgroundColor=#FFFFFF;')
            lab = val(e['label']) if e['label'] else ''
            pts = ''.join(f'<mxPoint x="{x}" y="{y}"/>' for x, y in e['pts'])
            geo = f'<mxGeometry relative="1" as="geometry">' + (f'<Array as="points">{pts}</Array>' if pts else '') + '</mxGeometry>'
            cells.append(f'<mxCell id="e{i}" value="{lab}" style="{st}" edge="1" parent="1" source="{e["s"]}" target="{e["t"]}">{geo}</mxCell>')
        xml = (f'<mxfile host="app.diagrams.net"><diagram id="{name}" name="{name}">'
               f'<mxGraphModel dx="1000" dy="800" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="{self.W}" pageHeight="{self.H}" math="0" shadow="0">'
               f'<root>{"".join(cells)}</root></mxGraphModel></diagram></mxfile>')
        open(path, 'w', encoding='utf-8').write(xml)
