# Data

The datasets are public but are not redistributed here. Download them and place the files as shown.

| File in this folder | Dataset | Source |
|---|---|---|
| `timss/bsgsgpm8.sav` | TIMSS 2023 Grade 8, Singapore, student background file (SPSS) | IEA Data Repository: https://www.iea.nl/data-tools/repository/timss |
| `data.csv` | Predict Students' Dropout and Academic Success (semicolon-separated) | UCI Machine Learning Repository: https://doi.org/10.24432/C5MC89 |
| `student-por.csv`, `student-mat.csv` | Student Performance (semicolon-separated) | UCI Machine Learning Repository: https://doi.org/10.24432/C5TG7T |
| `xAPI-Edu-Data.csv` | Students' Academic Performance (xAPI-Edu-Data) | Kaggle: https://www.kaggle.com/datasets/aljarah/xAPI-Edu-Data |

The TIMSS file name follows the IEA convention: `bsg` (student background) + `sgp` (Singapore) + `m8` (TIMSS 2023, Grade 8).
