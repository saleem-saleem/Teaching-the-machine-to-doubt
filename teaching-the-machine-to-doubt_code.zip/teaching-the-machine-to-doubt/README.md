# Teaching the Machine to Doubt

Code for the paper **"Teaching the Machine to Doubt: Pedagogy-Informed and Uncertainty-Aware Prediction of Student Performance"**.

The pipeline has three stages:

1. **Learner profiling.** Features are grouped into Knowledge, Skill and Attitude domains plus a background block. Each domain is checked with the KMO index, Bartlett's test and factor analysis.
2. **DA-CPSO-RF feature selection.** A binary particle swarm with a chaotic (logistic-map) start and a domain-aware repair step selects at most 20 features. A Random Forest scores each subset with inner cross-validation.
3. **KSA-EADE prediction and referral.** An evidential network with attention over the domains predicts the performance band (At-Risk, Moderate, High). Its Dirichlet output gives total, aleatoric and epistemic uncertainty. The output is fused with the Random Forest, and the most uncertain learners are referred to an advisor.

Every data-dependent step runs inside stratified five-fold cross-validation (seed 20260715).

## Repository structure

```
code/        pipeline, baselines, analysis, statistics, SHAP, CPU profile and figures
data/        place the public datasets here (see data/README.md)
results/     outputs of the runs reported in the paper (tables as CSV, fold-wise subsets, predictions)
diagrams/    draw.io sources and script for Figures 1-5 (method flowcharts)
```

| File | Purpose |
|---|---|
| `code/data.py` | Stage 1 on TIMSS 2023 (screening, domain map, KMO/Bartlett/factor analysis, bands) |
| `code/data_pub.py` | Stage 1 on the Dropout, Student Performance and xAPI datasets |
| `code/common.py` | Paths, folds and fold-wise imputation and scaling |
| `code/fs.py` | DA-CPSO-RF and the ten baseline selectors |
| `code/model.py` | KSA-EADE and the same-backbone baselines (JAX) |
| `code/run_fs.py` | Runs Stage 2 for all selectors, ablations and sensitivity settings |
| `code/run_stage3.py` | Runs Stage 3, the baselines, fusion and network ablations |
| `code/analysis.py`, `code/verify.py` | Result tables V1–V20 and arithmetic checks |
| `code/summary.py` | Cross-dataset summary tables S1–S4 |
| `code/stats_extra.py` | Friedman/Nemenyi, McNemar with Holm correction, bootstrap CIs, kappa and MCC |
| `code/shap_run.py` | TreeSHAP values for the At-Risk band |
| `code/profile_cpu.py` | CPU time and peak memory of every method |
| `code/res_figs.py`, `code/fig14.py`, `code/extra_figs.py` | Result figures |

## Setup

Python 3.11 or later. No GPU is needed.

```
pip install -r requirements.txt
```

The runs in the paper used Python 3.13, NumPy 2.5, scikit-learn 1.9, JAX 0.11 and SHAP 0.54 on two CPU cores.

## Reproducing the results

1. Download the datasets into `data/` as described in `data/README.md`.
2. Run everything:

```
cd code
sh run_all.sh
```

or one dataset at a time:

```
sh run_dataset.sh xapi      # timss | dropout | por | mat | xapi
```

All outputs are written to `results/out_<dataset>/`, `results/extra/` and `results/figures/`. The full run takes several hours on two CPU cores; most of the time is spent in the wrapper searches.

## Mapping to the paper

| Paper | Output |
|---|---|
| Stage 1 checks | `results/out_*/V1_stage1_measurement.csv`, `T_stage1_loadings.csv` |
| Selector accuracy and stability | `V5_selection_stability.csv`, `V7_search_ablation.csv`, `V8_sensitivity.csv` |
| Model comparison, per-band results | `V9_model_comparison.csv`, `V10_per_class.csv` |
| Calibration, uncertainty, referral | `V11_calibration_fused.csv`, `V12_uncertainty_by_outcome.csv`, `V13_misclassification_detection.csv`, `V14_selective_prediction.csv` |
| Ablations | `V15_architecture_ablation.csv`, `V16_cumulative_pipeline.csv` |
| Subgroups, plausible values, cost | `V17_subgroups.csv`, `out_timss/V18_plausible_values.csv`, `V19_cost.csv` |
| Attention | `V20_attention_weights.csv` |
| Statistical tests, SHAP | `results/extra/*.csv` |
| CPU profile | `results/cpu_profile.jsonl` |

## Data licences

The datasets are not redistributed. Please cite their original sources (see the paper and `data/README.md`) and follow their terms of use.

## Citation

If you use this code, please cite the paper (see `CITATION.cff`).

## Licence

MIT (see `LICENSE`).
