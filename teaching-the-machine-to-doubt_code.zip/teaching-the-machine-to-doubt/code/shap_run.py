"""TreeSHAP on the fold-wise Stage-2 forests (the forest carries the fused prediction with weight rho)."""
from paths import CODE, DATA, RES
import json, os
import numpy as np, pandas as pd
import shap
from sklearn.ensemble import RandomForestClassifier

K = RES; X = f'{K}/extra'; os.makedirs(X, exist_ok=True)
DS = [('TIMSS', 'timss', f'{K}/out_timss'), ('Dropout', 'dropout', f'{K}/out_dropout'), ('Portuguese', 'por', f'{K}/out_por'),
      ('Mathematics', 'mat', f'{K}/out_mat'), ('xAPI', 'xapi', f'{K}/out_xapi')]
import importlib, sys
sys.path.insert(0, CODE)
out_rows, dom_rows = [], []
store = {}
for dn, key, p in DS:
    os.environ['DATASET'] = key
    import common; importlib.reload(common)
    df, meta = common.load(); F = meta['features']; y = df['y'].values
    folds = common.outer_folds(y); subs = json.load(open(f'{p}/fs_main.json'))['DA-CPSO-RF']
    S = np.zeros((len(y), len(F))); Z = np.full((len(y), len(F)), np.nan)
    for v, (tr, te) in enumerate(folds):
        fi = [F.index(s) for s in subs[v]['subset']]
        prep = common.Prep(F, meta['ordinal']).fit(df.iloc[tr]); Xa = prep.transform(df)
        rf = RandomForestClassifier(100, random_state=common.SEED, n_jobs=2).fit(Xa[tr][:, fi], y[tr])
        sv = shap.TreeExplainer(rf).shap_values(Xa[te][:, fi])
        sv = np.asarray(sv)
        s0 = sv[:, :, 0] if sv.ndim == 3 and sv.shape[-1] == 3 else sv[0]       # At-Risk class
        S[np.ix_(te, fi)] = s0; Z[np.ix_(te, fi)] = Xa[te][:, fi]
    lab = meta['labels']
    mabs = np.abs(S).mean(0)
    for j, f in enumerate(F):
        out_rows.append(dict(dataset=dn, feature=f, label=lab.get(f, f), domain=meta['domain_of'][f], mean_abs_shap=mabs[j],
                             selected_folds=int(sum(f in s['subset'] for s in subs))))
    tot = mabs.sum()
    for dom in ['Knowledge', 'Skill', 'Attitude', 'Context']:
        idx = [j for j, f in enumerate(F) if meta['domain_of'][f] == dom]
        dom_rows.append(dict(dataset=dn, domain=dom, shap_share=mabs[idx].sum() / tot))
    store[dn] = dict(S=S, Z=Z, F=F, labels=[lab.get(f, f) for f in F], dom=[meta['domain_of'][f] for f in F], y=y)
    print(dn, 'done')
pd.DataFrame(out_rows).to_csv(f'{X}/shap_features.csv', index=False)
pd.DataFrame(dom_rows).to_csv(f'{X}/shap_domains.csv', index=False)
np.save(f'{X}/shap_store.npy', store, allow_pickle=True)
r = pd.DataFrame(out_rows)
for dn in r.dataset.unique():
    print(r[r.dataset == dn].sort_values('mean_abs_shap', ascending=False).head(8)[['label', 'domain', 'mean_abs_shap', 'selected_folds']].round(4).to_string())
print(pd.DataFrame(dom_rows).pivot(index='domain', columns='dataset', values='shap_share').round(3))
