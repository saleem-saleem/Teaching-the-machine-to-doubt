"""Extra statistical analyses: Friedman + Nemenyi, McNemar (Holm), bootstrap CIs, kappa/MCC."""
from paths import CODE, DATA, RES
import os, json
import numpy as np, pandas as pd
from scipy import stats
from sklearn.metrics import f1_score, roc_auc_score, cohen_kappa_score, matthews_corrcoef, accuracy_score

K = RES; X = f'{K}/extra'; os.makedirs(X, exist_ok=True)
DS = [('TIMSS', f'{K}/out_timss'), ('Dropout', f'{K}/out_dropout'), ('Portuguese', f'{K}/out_por'), ('Mathematics', f'{K}/out_mat'), ('xAPI', f'{K}/out_xapi')]
MOD = [('KSA-EADE', 'KSA-EADE'), ('RF', 'Random Forest'), ('Softmax MLP', 'Softmax MLP'), ('MC Dropout (50 passes)', 'MC Dropout'),
       ('Temperature Scaling', 'Temperature Scaling'), ('Deep Ensemble (3 models)', 'Deep Ensemble')]
SEED = 20260715


def ylab(p):
    return pd.read_csv(f'{p}/timss_sgp_analytic.csv' if p.endswith('/out_timss') else f'{p}/analytic.csv')['y'].values


def nemenyi_q(k):
    # two-tailed Nemenyi critical values (alpha = 0.05), Demsar (2006)
    return {2: 1.960, 3: 2.343, 4: 2.569, 5: 2.728, 6: 2.850, 7: 2.949, 8: 3.031, 9: 3.102, 10: 3.164, 11: 3.219}[k]


acc = pd.DataFrame(index=[m for _, m in MOD], columns=[d for d, _ in DS], dtype=float)
rows_mc, rows_boot, rows_km = [], [], []
P = {}
for dn, p in DS:
    z = np.load(f'{p}/stage3_y_DA-CPSO-RF.npz'); y = ylab(p)
    preds = {}
    for key, lab in MOD:
        pr = z[f'{key}|p_fused']; yh = pr.argmax(1); preds[lab] = (yh, pr)
        acc.loc[lab, dn] = (yh == y).mean()
        rows_km.append(dict(dataset=dn, model=lab, kappa=cohen_kappa_score(y, yh), qwk=cohen_kappa_score(y, yh, weights='quadratic'),
                            mcc=matthews_corrcoef(y, yh), balanced_acc=np.mean([(yh[y == c] == c).mean() for c in range(3)])))
    P[dn] = (y, preds)
    # McNemar exact, KSA-EADE vs each baseline
    a = preds['KSA-EADE'][0] == y
    ps = []
    for _, lab in MOD[1:]:
        b = preds[lab][0] == y
        n01, n10 = int((a & ~b).sum()), int((~a & b).sum())
        pv = stats.binomtest(min(n01, n10), n01 + n10, 0.5).pvalue if n01 + n10 else 1.0
        ps.append(pv); rows_mc.append(dict(dataset=dn, baseline=lab, ksa_only=n01, baseline_only=n10, p=pv))
    # Holm within dataset
    order = np.argsort(ps); m = len(ps); adj = np.empty(m); run = 0
    for r, i in enumerate(order):
        run = max(run, min(1, (m - r) * ps[i])); adj[i] = run
    for j, i in enumerate(range(len(rows_mc) - m, len(rows_mc))): rows_mc[i]['p_holm'] = adj[j]
    # bootstrap CIs for KSA-EADE
    rng = np.random.default_rng(SEED); yh, pr = preds['KSA-EADE']; n = len(y); B = 2000
    stat = {'Accuracy': [], 'Macro-F1': [], 'Macro AUROC': [], 'At-Risk recall': []}
    for _ in range(B):
        i = rng.integers(0, n, n); yy, hh, pp = y[i], yh[i], pr[i]
        stat['Accuracy'].append((yy == hh).mean()); stat['Macro-F1'].append(f1_score(yy, hh, average='macro'))
        stat['Macro AUROC'].append(roc_auc_score(yy, pp, multi_class='ovr', average='macro'))
        stat['At-Risk recall'].append((hh[yy == 0] == 0).mean())
    point = {'Accuracy': (y == yh).mean(), 'Macro-F1': f1_score(y, yh, average='macro'),
             'Macro AUROC': roc_auc_score(y, pr, multi_class='ovr', average='macro'), 'At-Risk recall': (yh[y == 0] == 0).mean()}
    for k_, v in stat.items():
        lo, hi = np.percentile(v, [2.5, 97.5]); rows_boot.append(dict(dataset=dn, measure=k_, value=point[k_], lo=lo, hi=hi))

# Friedman + Nemenyi on dataset-level accuracy (models)
def friedman(tab):
    R = tab.rank(axis=0, ascending=False)            # rank 1 = best, ties averaged
    k, N = tab.shape
    chi, pv = stats.friedmanchisquare(*[tab.loc[m].values for m in tab.index])
    cd = nemenyi_q(k) * np.sqrt(k * (k + 1) / (6 * N))
    return R.mean(axis=1).sort_values(), chi, pv, cd, k, N
rk, chi, pv, cd, k, N = friedman(acc)
fr = [dict(test='Models (accuracy)', k=k, N=N, chi2=chi, p=pv, CD=cd, ranks=json.dumps(rk.round(2).to_dict()))]

# selectors (accuracy of RF on selected subsets)
SEL = ['Mutual information', 'Chi-square', 'ReliefF', 'mRMR', 'RFE (Random Forest)', 'LASSO (L1)', 'Random Forest importance', 'Boruta',
       'Genetic Algorithm', 'Particle Swarm Optimization', 'DA-CPSO-RF (proposed)']
sa = pd.DataFrame({dn: pd.read_csv(f'{p}/V5_selection_stability.csv').set_index('method').loc[SEL, 'acc_mean'] for dn, p in DS})
sj = pd.DataFrame({dn: pd.read_csv(f'{p}/V5_selection_stability.csv').set_index('method').loc[SEL, 'jaccard'] for dn, p in DS})
rk2, chi2_, pv2, cd2, k2, N2 = friedman(sa)
fr.append(dict(test='Selectors (accuracy)', k=k2, N=N2, chi2=chi2_, p=pv2, CD=cd2, ranks=json.dumps(rk2.round(2).to_dict())))
# wrappers only: accuracy and Jaccard
W3 = ['Genetic Algorithm', 'Particle Swarm Optimization', 'DA-CPSO-RF (proposed)']
for nm, tb in [('Wrappers (accuracy)', sa.loc[W3]), ('Wrappers (Jaccard)', sj.loc[W3])]:
    r_, c_, p_, d_, kk, NN = friedman(tb)
    fr.append(dict(test=nm, k=kk, N=NN, chi2=c_, p=p_, CD=d_, ranks=json.dumps(r_.round(2).to_dict())))
# fold-level Friedman for models: 25 blocks (dataset x fold)
blocks = []
for dn, p in DS:
    y, preds = P[dn]
    folds = __import__('sklearn.model_selection', fromlist=['StratifiedKFold']).StratifiedKFold(5, shuffle=True, random_state=SEED).split(np.zeros(len(y)), y)
    for tr, te in folds:
        blocks.append([(preds[lab][0][te] == y[te]).mean() for _, lab in MOD])
bt = pd.DataFrame(np.array(blocks).T, index=[m for _, m in MOD])
r3, c3, p3, d3, kk, NN = friedman(bt)
fr.append(dict(test='Models (accuracy, 25 dataset-fold blocks)', k=kk, N=NN, chi2=c3, p=p3, CD=d3, ranks=json.dumps(r3.round(2).to_dict())))

pd.DataFrame(fr).to_csv(f'{X}/friedman.csv', index=False)
pd.DataFrame(rows_mc).to_csv(f'{X}/mcnemar.csv', index=False)
pd.DataFrame(rows_boot).to_csv(f'{X}/bootstrap.csv', index=False)
pd.DataFrame(rows_km).to_csv(f'{X}/kappa_mcc.csv', index=False)
acc.to_csv(f'{X}/acc_pooled.csv'); sa.to_csv(f'{X}/sel_acc.csv'); bt.to_csv(f'{X}/fold_blocks.csv')
print(pd.DataFrame(fr).to_string()); print(pd.DataFrame(rows_mc).round(4).to_string()); print(pd.DataFrame(rows_boot).round(3).to_string())
print(pd.DataFrame(rows_km).round(3).to_string())
