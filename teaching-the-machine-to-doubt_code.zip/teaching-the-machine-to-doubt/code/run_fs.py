"""Run all Stage-2 selectors across the outer folds. Usage: python run_fs.py <group>
groups: main (DA-CPSO-RF + ablation variants), baselines, sens"""
from paths import CODE, DATA, RES
import sys, json, time
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score
from common import load, outer_folds, Prep, SEED, OUT
from fs import binary_pso, baseline_select, DEFAULT

df, meta = load()
F = meta['features']; y = df['y'].values
dom_idx = [np.array([i for i, f in enumerate(F) if meta['domain_of'][f] == d]) for d in ['Knowledge', 'Skill', 'Attitude']]
folds = outer_folds(y)
group = sys.argv[1]
import os
if os.environ.get('DATASET') == 'mat' and (group.startswith('sens') or group == 'vmax'):
    json.dump({}, open(f'{OUT}/fs_{group}.json', 'w')); sys.exit(0)

if group == 'main':
    methods = {'DA-CPSO-RF': dict(chaotic=True, domain_aware=True), 'CPSO': dict(chaotic=True, domain_aware=False),
               'DA-PSO': dict(chaotic=False, domain_aware=True)}
    runs = [(m, kw, {}) for m, kw in methods.items()]
elif group == 'baselines':
    runs = [(m, None, {}) for m in ['Mutual information', 'Chi-square', 'ReliefF', 'mRMR', 'RFE (Random Forest)', 'LASSO (L1)',
                                    'Random Forest importance', 'Boruta', 'Genetic Algorithm', 'Particle Swarm Optimization']]
elif group == 'pso':
    runs = [('PSO', dict(chaotic=False, domain_aware=False), {})]
elif group == 'vmax':
    runs = [(f'sens_vmax={v}', dict(chaotic=True, domain_aware=True), {'vmax': v}) for v in (2.0, 4.0, 6.0)]
elif group.startswith('sens'):
    grid = [('P', 10), ('P', 20), ('T', 10), ('T', 22), ('w', 0.50), ('w', 0.90), ('c1', 1.0), ('c1', 2.0),
            ('beta', 0.85), ('beta', 0.95), ('kmin', 2), ('kmin', 6)]
    part = int(group[4:]) if len(group) > 4 else None
    if part is not None: grid = grid[part::2]
    runs = [(f'sens_{p}={v}', dict(chaotic=True, domain_aware=True), {p: v} if p != 'c1' else {'c1': v, 'c2': v}) for p, v in grid]

res = {}
for name, kw, cfg in runs:
    rng = np.random.default_rng(SEED)
    out = []
    for v, (tr, te) in enumerate(folds):
        prep = Prep(F, meta['ordinal']).fit(df.iloc[tr])
        Xtr, Xte = prep.transform(df.iloc[tr]), prep.transform(df.iloc[te])
        t0 = time.time()
        if kw is not None:
            sel, info = binary_pso(Xtr, y[tr], dom_idx, cfg=cfg, rng=rng, seed=SEED, **kw)
        else:
            sel = baseline_select(name, Xtr, y[tr], DEFAULT['k'], SEED, rng); info = {}
        secs = time.time() - t0
        rf = RandomForestClassifier(100, random_state=SEED, n_jobs=2).fit(Xtr[:, sel], y[tr])
        pred = rf.predict(Xte[:, sel])
        out.append(dict(fold=v, subset=[F[i] for i in sel], size=int(len(sel)), acc=float((pred == y[te]).mean()),
                        macro_f1=float(f1_score(y[te], pred, average='macro')), seconds=secs,
                        conv=info.get('conv'), acc_in=info.get('acc_in'), hist=info.get('hist')))
        print(name, v, len(sel), round(out[-1]['acc'], 3), round(secs, 1), info.get('conv'), flush=True)
    res[name] = out
    json.dump(res, open(f'{OUT}/fs_{group}.json', 'w'), indent=1)
