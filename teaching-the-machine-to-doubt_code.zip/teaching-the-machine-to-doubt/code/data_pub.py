"""Build analysis-ready files for the UCI datasets with dataset-specific KSA blueprints.
Usage: python data_pub.py por|mat|dropout"""
from paths import CODE, DATA, RES
import sys, os, json
import numpy as np, pandas as pd
from data import kmo, bartlett, varimax, cronbach

name = sys.argv[1]
OUT = f'{RES}/out_{name}'; os.makedirs(OUT, exist_ok=True)


def measurement(df, domains, labels):
    """Descriptive structure check of each domain block (no items are removed for non-questionnaire data)."""
    rows, loads = [], []
    for dom, cols in domains.items():
        X = df[cols].dropna().values.astype(float)
        X = X[:, X.std(axis=0) > 0]
        R = np.corrcoef(X, rowvar=False)
        w, Vv = np.linalg.eigh(R); o = np.argsort(w)[::-1]; w, Vv = w[o], Vv[:, o]
        r = max(1, int((w > 1).sum())); L = Vv[:, :r] * np.sqrt(w[:r]); Lr = varimax(L) if r > 1 else L
        Lr = Lr * np.sign(Lr.sum(axis=0)); maxl = np.abs(Lr).max(axis=1)
        chi2, dfb, pb = bartlett(X)
        rows.append(dict(domain=dom, items=len(cols), n_complete=len(X), KMO=kmo(X), bartlett_chi2=chi2, bartlett_df=dfb, bartlett_p=pb,
                         factors_retained=r, variance_explained=w[:r].sum() / X.shape[1], alpha=cronbach(X),
                         items_retained=len(cols), eigenvalues=';'.join(f'{x:.2f}' for x in w[:max(r, 3)])))
        for j, c in enumerate(cols):
            loads.append(dict(domain=dom, item=c, label=labels.get(c, c), **{f'F{f+1}': Lr[j, f] for f in range(min(r, 3))},
                              max_abs_loading=maxl[j], retained=True))
    pd.DataFrame(rows).to_csv(f'{OUT}/T_stage1_measurement.csv', index=False)
    pd.DataFrame(loads).to_csv(f'{OUT}/T_stage1_loadings.csv', index=False)
    print(pd.DataFrame(rows).round(3).to_string())


if name in ('por', 'mat'):
    raw = pd.read_csv(f'{DATA}/student-{name}.csv', sep=';')
    df = pd.DataFrame()
    yn = lambda s: (s == 'yes').astype(float)
    K = {'failures': raw['failures'], 'schoolsup': yn(raw['schoolsup']), 'paid': yn(raw['paid']), 'nursery': yn(raw['nursery'])}
    S = {'studytime': raw['studytime'], 'absences': raw['absences'], 'activities': yn(raw['activities']),
         'internet': yn(raw['internet']), 'traveltime': raw['traveltime']}
    A = {'higher': yn(raw['higher']), 'freetime': raw['freetime'], 'goout': raw['goout'], 'Dalc': raw['Dalc'],
         'Walc': raw['Walc'], 'romantic': yn(raw['romantic'])}
    C = {'school_GP': (raw['school'] == 'GP').astype(float), 'male': (raw['sex'] == 'M').astype(float), 'age': raw['age'],
         'urban': (raw['address'] == 'U').astype(float), 'famsize_gt3': (raw['famsize'] == 'GT3').astype(float),
         'parents_together': (raw['Pstatus'] == 'T').astype(float), 'Medu': raw['Medu'], 'Fedu': raw['Fedu'],
         'famsup': yn(raw['famsup']), 'famrel': raw['famrel'], 'health': raw['health']}
    for col in ['Mjob', 'Fjob', 'reason', 'guardian']:
        for lv in sorted(raw[col].unique()): C[f'{col}_{lv}'] = (raw[col] == lv).astype(float)
    blocks = {'Knowledge': K, 'Skill': S, 'Attitude': A, 'Context': C}
    for b in blocks.values():
        for k, v in b.items(): df[k] = v
    df['G3'] = raw['G3']
    c1, c2 = np.percentile(df['G3'], [18, 68]); df['y'] = np.digitize(df['G3'], [c1, c2])
    df['grp_sex'] = raw['sex'].map({'F': 'Female', 'M': 'Male'}); df['grp_address'] = raw['address'].map({'U': 'Urban', 'R': 'Rural'})
    df['grp_school'] = raw['school']
    groups = {'grp_sex': ['Female', 'Male'], 'grp_address': ['Urban', 'Rural'], 'grp_school': ['GP', 'MS']}
    cont = 'G3'; target_desc = f'Final grade G3 (0–20), bands at 18th/68th percentiles ({c1:g} / {c2:g}); G1 and G2 excluded'
    ordinal = ['failures', 'studytime', 'traveltime', 'freetime', 'goout', 'Dalc', 'Walc', 'Medu', 'Fedu', 'famrel', 'health']
elif name == 'xapi':
    raw = pd.read_csv(f'{DATA}/xAPI-Edu-Data.csv')
    df = pd.DataFrame()
    K = {'visited_resources': raw['VisITedResources'], 'announcements_viewed': raw['AnnouncementsView']}
    S = {'raised_hands': raw['raisedhands'], 'discussion_posts': raw['Discussion']}
    A = {'rarely_absent': (raw['StudentAbsenceDays'] == 'Under-7').astype(float),
         'parent_answered_survey': (raw['ParentAnsweringSurvey'] == 'Yes').astype(float),
         'parent_satisfied': (raw['ParentschoolSatisfaction'] == 'Good').astype(float)}
    C = {'male': (raw['gender'] == 'M').astype(float), 'mother_responsible': (raw['Relation'] == 'Mum').astype(float),
         'second_semester': (raw['Semester'] == 'S').astype(float), 'grade_level': raw['GradeID'].str[2:].astype(float)}
    for col, levels in [('StageID', None), ('SectionID', None), ('Topic', None)]:
        for lv in sorted(raw[col].unique()): C[f'{col}_{lv}'] = (raw[col] == lv).astype(float)
    top = ['KW', 'Jordan', 'Palestine', 'Iraq', 'lebanon', 'Tunis', 'SaudiArabia']
    for lv in top: C[f'nationality_{lv}'] = (raw['NationalITy'] == lv).astype(float)
    C['nationality_other'] = (~raw['NationalITy'].isin(top)).astype(float)
    blocks = {'Knowledge': K, 'Skill': S, 'Attitude': A, 'Context': C}
    for b in blocks.values():
        for k, v in b.items(): df[k] = v.astype(float)
    df['y'] = raw['Class'].map({'L': 0, 'M': 1, 'H': 2})
    df['grp_gender'] = raw['gender'].map({'F': 'Female', 'M': 'Male'})
    df['grp_stage'] = raw['StageID'].map({'lowerlevel': 'Lower', 'MiddleSchool': 'Middle', 'HighSchool': 'High'})
    df['grp_semester'] = raw['Semester'].map({'F': 'First', 'S': 'Second'})
    groups = {'grp_gender': ['Female', 'Male'], 'grp_stage': ['Lower', 'Middle', 'High'], 'grp_semester': ['First', 'Second']}
    cont = None; target_desc = 'Native outcome: Low (At-Risk), Middle (Moderate), High'
    ordinal = []
else:
    raw = pd.read_csv(f'{DATA}/data.csv', sep=';'); raw.columns = [c.strip() for c in raw.columns]
    df = pd.DataFrame()
    cu = lambda s, k: f'Curricular units {s} sem ({k})'
    K = {c: raw[c] for c in ['Previous qualification (grade)', 'Admission grade', cu('1st', 'grade'), cu('2nd', 'grade'),
                              cu('1st', 'approved'), cu('2nd', 'approved')]}
    S = {c: raw[c] for c in [cu(s, k) for s in ['1st', '2nd'] for k in ['enrolled', 'evaluations', 'credited', 'without evaluations']]}
    A = {c: raw[c] for c in ['Tuition fees up to date', 'Debtor', 'Scholarship holder', 'Application order', 'Daytime/evening attendance']}
    C = {c: raw[c] for c in ['Marital status', 'Application mode', 'Course', 'Previous qualification', 'Nacionality',
                              "Mother's qualification", "Father's qualification", "Mother's occupation", "Father's occupation",
                              'Displaced', 'Educational special needs', 'Gender', 'Age at enrollment', 'International',
                              'Unemployment rate', 'Inflation rate', 'GDP']}
    blocks = {'Knowledge': K, 'Skill': S, 'Attitude': A, 'Context': C}
    for b in blocks.values():
        for k, v in b.items(): df[k] = v.astype(float)
    df['y'] = raw['Target'].map({'Dropout': 0, 'Enrolled': 1, 'Graduate': 2})
    df['grp_gender'] = raw['Gender'].map({1: 'Male', 0: 'Female'})
    df['grp_scholarship'] = raw['Scholarship holder'].map({1: 'Scholarship', 0: 'No scholarship'})
    df['grp_attendance'] = raw['Daytime/evening attendance'].map({1: 'Daytime', 0: 'Evening'})
    groups = {'grp_gender': ['Female', 'Male'], 'grp_scholarship': ['No scholarship', 'Scholarship'], 'grp_attendance': ['Daytime', 'Evening']}
    cont = None; target_desc = 'Native outcome: Dropout (At-Risk), Enrolled (Moderate), Graduate (High)'
    ordinal = []

features = [k for b in blocks.values() for k in b]
domain_of = {k: d for d, b in blocks.items() for k in b}
labels = {k: k for k in features}
measurement(df, {d: list(b) for d, b in blocks.items() if d != 'Context'}, labels)
df.to_csv(f'{OUT}/analytic.csv', index=False)
json.dump(dict(features=features, domain_of=domain_of, labels=labels, ordinal=ordinal, groups=groups, cont_target=cont,
               target_desc=target_desc, screen=dict(returned=len(df), excluded=0, analytic=len(df)), has_scores=False),
          open(f'{OUT}/meta.json', 'w'), indent=1)
print(name, df.shape, 'features', len(features), {d: len(b) for d, b in blocks.items()}, 'classes', df['y'].value_counts().sort_index().to_dict())
