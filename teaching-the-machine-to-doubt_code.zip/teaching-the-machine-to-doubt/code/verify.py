"""Independent arithmetic checks on the produced tables."""
from paths import CODE, DATA, RES
import json, itertools
import numpy as np, pandas as pd
from scipy import stats
from common import OUT, DATASET
ok = True
def check(name, cond):
    global ok; ok &= bool(cond); print(('PASS ' if cond else 'FAIL ') + name)

df = pd.read_csv(f'{OUT}/timss_sgp_analytic.csv' if DATASET == 'timss' else f'{OUT}/analytic.csv'); y = df['y'].values; N = len(y)
z = np.load(f'{OUT}/stage3_y_DA-CPSO-RF.npz'); pf = z['KSA-EADE|p_fused']; pred = pf.argmax(1)
cm = np.zeros((3, 3), int)
for a, b in zip(y, pred): cm[a, b] += 1
pc = pd.read_csv(f'{OUT}/V10_per_class.csv')
for c in range(3):
    prec = cm[c, c] / cm[:, c].sum(); rec = cm[c, c] / cm[c].sum(); f1 = 2 * prec * rec / (prec + rec)
    check(f'class {c} precision/recall/F1 from confusion matrix', np.allclose([prec, rec, f1], pc.loc[c, ['precision', 'recall', 'f1']].values.astype(float), atol=6e-4))
check('confusion matrix sums to N', cm.sum() == N)
check('accuracy = trace / N', abs(np.trace(cm) / N - (pred == y).mean()) < 1e-12)
check('probabilities sum to 1', np.allclose(pf.sum(1), 1))
check('no missing out-of-fold predictions', not np.isnan(pf).any())
# uncertainty decomposition: total = aleatoric + epistemic
check('total = aleatoric + epistemic', np.allclose(z['KSA-EADE|total'], z['KSA-EADE|aleatoric'] + z['KSA-EADE|epistemic']))
check('vacuity in (0, 1]', (z['KSA-EADE|vacuity'] > 0).all() and (z['KSA-EADE|vacuity'] <= 1).all())
# Kuncheva vs Jaccard for equal-size subsets
fs = {**json.load(open(f'{OUT}/fs_baselines.json')), **json.load(open(f'{OUT}/fs_main.json'))}
L = len(json.load(open(f'{OUT}/meta.json'))['features']); sel = pd.read_csv(f'{OUT}/V5_selection_stability.csv')
for m, res in fs.items():
    subs = [set(r['subset']) for r in res]
    if len({len(s) for s in subs}) == 1:
        k = len(subs[0])
        for i, j in itertools.combinations(range(5), 2):
            rr = len(subs[i] & subs[j]); I = (rr - k * k / L) / (k - k * k / L); J = rr / len(subs[i] | subs[j])
            D = 2 * rr / (2 * k)
            assert abs(D - 2 * J / (1 + J)) < 1e-12
check('Dice = 2J/(1+J) for every equal-size pair', True)
# Wilson interval spot check
sg = pd.read_csv(f'{OUT}/V17_subgroups.csv')
if DATASET == 'timss':
    g0, c0 = 'grp_sex', 'Girl'
else:
    g0, order0 = list(json.load(open(f'{OUT}/meta.json'))['groups'].items())[0]; c0 = order0[0]
m = (df[g0] == c0).values; k = (pred[m] == y[m]).sum(); n = m.sum()
from statsmodels.stats.proportion import proportion_confint
lo, hi = proportion_confint(k, n, method='wilson')
check('Wilson CI (girls) matches statsmodels', f'[{lo:.3f}, {hi:.3f}]' in sg.loc[0, 'accuracy'])
# class bands
if DATASET == 'timss': check('band shares 18/50/32 %', np.allclose(np.bincount(y) / N, [0.18, 0.50, 0.32], atol=0.002))
# parameter count for 4 blocks, k = 20
h, H, C = 32, 64, 3
check('parameter formula 7,267 for four blocks', h * (20 + 4) + h + (h + 1) * H + (H + 1) * H + (H + 1) * C == 7267)
check('parameter formula 7,235 for three blocks', h * (20 + 3) + h + (h + 1) * H + (H + 1) * H + (H + 1) * C == 7235)
print('ALL PASS' if ok else 'SOME CHECKS FAILED')
