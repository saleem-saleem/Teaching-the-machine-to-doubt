#!/bin/sh
# Reproduce every result, table and figure of the paper.
set -e
cd "$(dirname "$0")"
for D in timss dropout por mat xapi; do sh run_dataset.sh $D; done
python3 summary.py        # cross-dataset summary tables S1-S4
python3 stats_extra.py    # Friedman/Nemenyi, McNemar (Holm), bootstrap CIs, kappa/MCC
python3 shap_run.py       # TreeSHAP on the fold-wise forests
sh run_profile.sh         # CPU time and memory profile
python3 res_figs.py && python3 fig14.py && python3 extra_figs.py   # result figures
