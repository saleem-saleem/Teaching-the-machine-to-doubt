"""Stage 3: KSA-EADE, baselines and architecture ablations on the DA-CPSO-RF subsets.
Usage: python run_stage3.py [label_column] [subset_method]"""
import sys, json, time
import numpy as np
from scipy.optimize import minimize_scalar
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from common import load, outer_folds, Prep, SEED, OUT
from model import train, predict, dirichlet_uncertainty, entropy, n_params, macs, HP

label = sys.argv[1] if len(sys.argv) > 1 else 'y'
subset_method = sys.argv[2] if len(sys.argv) > 2 else 'DA-CPSO-RF'
full = label == 'y' and subset_method == 'DA-CPSO-RF'
df, meta = load(); F = meta['features']; y = df[label].values
folds = outer_folds(df['y'].values)          # identical folds for every label
subsets = json.load(open(f'{OUT}/fs_main.json'))[subset_method]
RHO = [0.0, 0.25, 0.5, 0.75]


def softmax(o):
    e = np.exp(o - o.max(-1, keepdims=True)); return e / e.sum(-1, keepdims=True)


def nll(p, yy):
    return -np.log(np.clip(p[np.arange(len(yy)), yy], 1e-12, 1)).mean()


def latency(fn, X, reps=20):
    fn(X); t = []
    for _ in range(reps):
        t0 = time.perf_counter(); fn(X); t.append((time.perf_counter() - t0) / len(X) * 1000)
    return float(np.mean(t)), float(np.std(t))


N = len(y)
store = {}
def put(method, key, idx, val):
    d = store.setdefault(method, {})
    if key not in d:
        shape = (N,) + np.shape(val)[1:]
        d[key] = np.full(shape, np.nan)
    d[key][idx] = val

meta_rows = []
for v, (tr, te) in enumerate(folds):
    sub = subsets[v]['subset']; fi = [F.index(s) for s in sub]
    prep = Prep(F, meta['ordinal']).fit(df.iloc[tr]); X = prep.transform(df)[:, fi]
    dom = [meta['domain_of'][s] for s in sub]
    blocks = [np.array([i for i, d in enumerate(dom) if d == D]) for D in ['Knowledge', 'Skill', 'Attitude', 'Context'] if D in dom]
    bnames = [D for D in ['Knowledge', 'Skill', 'Attitude', 'Context'] if D in dom]
    a, b = train_test_split(tr, test_size=0.15, stratify=y[tr], random_state=SEED + v)
    # forests: one without the validation split (for choosing rho), one on the full training partition
    rf_a = RandomForestClassifier(100, random_state=SEED, n_jobs=2).fit(X[a], y[a]); prf_b = rf_a.predict_proba(X[b])
    t0 = time.time(); rf = RandomForestClassifier(100, random_state=SEED, n_jobs=2).fit(X[tr], y[tr]); rf_time = time.time() - t0
    prf = rf.predict_proba(X[te]); put('RF', 'p', te, prf); put('RF', 'p_fused', te, prf)

    def record(name, p_te, p_b, unc, info, params, mac, lat):
        rho = min(RHO, key=lambda r: nll(r * prf_b + (1 - r) * p_b, y[b]))
        put(name, 'p', te, p_te); put(name, 'p_fused', te, rho * prf + (1 - rho) * p_te)
        for k_, u in unc.items(): put(name, k_, te, u)
        meta_rows.append(dict(method=name, fold=v, rho=rho, params=params, macs=mac, train_seconds=info.get('train_seconds'),
                              epochs=info.get('epochs'), latency_ms=lat[0], latency_sd=lat[1], blocks=len(blocks), k=len(fi)))

    variants = [('KSA-EADE', 'edl', True, True), ('Softmax MLP', 'softmax', True, True)]
    if full:
        variants += [('- Attention (mean pooling)', 'edl', False, True), ('- KSA partitioning (shared block)', 'edl', False, False)]
    for name, kind, att, part in variants:
        p, fwd, info = train(X[a], y[a], X[b], y[b], blocks, kind=kind, attention=att, partition=part, seed=1)
        o, aw = predict(p, fwd, X[te], kind); ob, _ = predict(p, fwd, X[b], kind)
        if kind == 'edl':
            u = dirichlet_uncertainty(o); pt, pb = u['p'], dirichlet_uncertainty(ob)['p']
            unc = {k_: u[k_] for k_ in ['total', 'aleatoric', 'epistemic', 'vacuity']}
            if name == 'KSA-EADE':
                for j, bn in enumerate(bnames): put(name, 'att_' + bn, te, aw[:, j])
        else:
            pt, pb = softmax(o), softmax(ob); unc = {'total': entropy(pt)}
        lat = latency(lambda Z: predict(p, fwd, Z, kind), X[te])
        record(name, pt, pb, unc, info, n_params(p), macs(len(fi), len(blocks), partition=part, attention=att), lat)
        if name == 'Softmax MLP':
            base_p, base_fwd, base_info, base_o, base_ob = p, fwd, info, o, ob
    if not full:
        continue
    # temperature scaling on the validation split
    Tt = minimize_scalar(lambda T: nll(softmax(base_ob / T), y[b]), bounds=(0.05, 10), method='bounded').x
    pt, pb = softmax(base_o / Tt), softmax(base_ob / Tt)
    record('Temperature Scaling', pt, pb, {'total': entropy(pt)}, base_info, n_params(base_p) + 1,
           macs(len(fi), len(blocks)), latency(lambda Z: predict(base_p, base_fwd, Z, 'softmax'), X[te]))
    # MC dropout
    p, fwd, info = train(X[a], y[a], X[b], y[b], blocks, kind='softmax', dropout=HP['dropout'], seed=1)
    ot, _ = predict(p, fwd, X[te], 'softmax', passes=50, seed=v); ob, _ = predict(p, fwd, X[b], 'softmax', passes=50, seed=v)
    P = softmax(ot); pt = P.mean(0); pb = softmax(ob).mean(0)
    al = entropy(P).mean(0); unc = {'total': entropy(pt), 'aleatoric': al, 'epistemic': entropy(pt) - al}
    record('MC Dropout (50 passes)', pt, pb, unc, info, n_params(p), 50 * macs(len(fi), len(blocks)),
           latency(lambda Z: predict(p, fwd, Z, 'softmax', passes=50), X[te], reps=5))
    # deep ensemble of three softmax networks
    Ps, Pbs, tsec, mods = [], [], 0, []
    for s in (1, 2, 3):
        p, fwd, info = train(X[a], y[a], X[b], y[b], blocks, kind='softmax', seed=s)
        o, _ = predict(p, fwd, X[te], 'softmax'); ob, _ = predict(p, fwd, X[b], 'softmax')
        Ps.append(softmax(o)); Pbs.append(softmax(ob)); tsec += info['train_seconds']; mods.append((p, fwd))
    P = np.stack(Ps); pt = P.mean(0); pb = np.stack(Pbs).mean(0)
    al = entropy(P).mean(0); unc = {'total': entropy(pt), 'aleatoric': al, 'epistemic': entropy(pt) - al}
    record('Deep Ensemble (3 models)', pt, pb, unc, dict(train_seconds=tsec, epochs=None), 3 * n_params(mods[0][0]),
           3 * macs(len(fi), len(blocks)), latency(lambda Z: [predict(pp, ff, Z, 'softmax') for pp, ff in mods], X[te]))
    meta_rows.append(dict(method='RF', fold=v, train_seconds=rf_time))
    print('fold', v, 'done', flush=True)

tag = f'{label}_{subset_method}'.replace(' ', '_')
np.savez_compressed(f'{OUT}/stage3_{tag}.npz', **{f'{m}|{k}': a for m, d in store.items() for k, a in d.items()})
json.dump(meta_rows, open(f'{OUT}/stage3_{tag}_meta.json', 'w'), indent=1)
print('saved', tag)
