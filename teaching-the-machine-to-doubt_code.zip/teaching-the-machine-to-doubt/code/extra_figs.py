from paths import CODE, DATA, RES
import json
import numpy as np, pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc
exec(open(f'{CODE}/res_figs.py').read().split('# ---- Figure 6')[0])
X = f'{RES}/extra'
DOMC = {'Knowledge': CAT[0], 'Skill': CAT[1], 'Attitude': CAT[2], 'Context': '#9c9b96'}
DOMN = {'Knowledge': 'Knowledge', 'Skill': 'Skill', 'Attitude': 'Attitude', 'Context': 'Background'}
PRETTY = {'rarely_absent': 'Absence under 7 days', 'visited_resources': 'Resources visited', 'raised_hands': 'Hands raised',
          'announcements_viewed': 'Announcements viewed', 'parent_answered_survey': 'Parent answered survey', 'discussion_posts': 'Discussion posts',
          'parent_satisfied': 'Parent satisfied with school', 'mother_responsible': 'Mother is guardian', 'failures': 'Past class failures',
          'higher': 'Wants higher education', 'school_GP': 'School (GP)', 'studytime': 'Weekly study time', 'goout': 'Going out with friends',
          'Walc': 'Weekend alcohol use', 'urban': 'Urban address', 'traveltime': 'Travel time', 'absences': 'School absences', 'paid': 'Paid extra classes',
          'Medu': "Mother's education", 'schoolsup': 'Extra school support', 'internet': 'Internet at home', 'Dalc': 'Workday alcohol use',
          'freetime': 'Free time', 'activities': 'Extra-curricular activities', 'romantic': 'In a relationship', 'nursery': 'Attended nursery',
          'Fedu': "Father's education", 'famrel': 'Family relationship', 'health': 'Health status', 'age': 'Age', 'male': 'Male',
          'Curricular units 2nd sem (approved)': 'Units approved, semester 2', 'Curricular units 1st sem (approved)': 'Units approved, semester 1',
          'Curricular units 2nd sem (grade)': 'Grade, semester 2', 'Curricular units 1st sem (grade)': 'Grade, semester 1',
          'Curricular units 1st sem (enrolled)': 'Units enrolled, semester 1', 'Curricular units 2nd sem (enrolled)': 'Units enrolled, semester 2',
          'Curricular units 1st sem (evaluations)': 'Evaluations, semester 1', 'Curricular units 2nd sem (evaluations)': 'Evaluations, semester 2',
          'Tuition fees up to date': 'Tuition fees up to date', 'Scholarship holder': 'Scholarship holder', 'Course': 'Course',
          'Age at enrollment': 'Age at enrolment', 'Admission grade': 'Admission grade', 'Debtor': 'Debtor',
          'Previous qualification (grade)': 'Prior qualification grade', 'Application mode': 'Application mode', 'Gender': 'Gender'}
pretty = lambda s: PRETTY.get(s, s.replace('_', ' ').capitalize() if s.islower() else s)
sh = pd.read_csv(f'{X}/shap_features.csv'); sh['nice'] = [pretty(f) if dn != 'TIMSS' else l for f, l, dn in zip(sh.feature, sh.label, sh.dataset)]
sh.to_csv(f'{X}/shap_features_named.csv', index=False)
NAMES = [n for _, n, _ in DS]

# ---- Figure: mean |SHAP| top 8 per dataset ----
fig, axs = plt.subplots(1, 5, figsize=(16, 3.9))
for ax, n in zip(axs, NAMES):
    t = sh[sh.dataset == n].sort_values('mean_abs_shap', ascending=False).head(8)[::-1]
    ax.barh(range(len(t)), t.mean_abs_shap, color=[DOMC[d] for d in t.domain], height=0.7)
    ax.set_yticks(range(len(t)), [s if len(s) < 30 else s[:28] + '…' for s in t.nice], fontsize=8.5)
    ax.set_title(n); ax.set_xlabel('Mean |SHAP| (At-Risk)'); ax.grid(axis='y', visible=False)
    ax.xaxis.set_major_locator(plt.MaxNLocator(3))
from matplotlib.patches import Patch
fig.legend(handles=[Patch(color=DOMC[d], label=DOMN[d]) for d in DOMC], ncol=4, loc='lower center', bbox_to_anchor=(0.5, -0.06))
fig.tight_layout(); fig.savefig(f'{OUT}/figure15.png'); plt.close(fig)

# ---- Figure: SHAP beeswarm-style for three datasets ----
store = np.load(f'{X}/shap_store.npy', allow_pickle=True).item()
fig, axs = plt.subplots(1, 3, figsize=(15.5, 4.2)); fig.subplots_adjust(left=0.14, right=0.9, wspace=0.95, bottom=0.14)
rng = np.random.default_rng(0)
for ax, n in zip(axs, ['TIMSS', 'Dropout', 'xAPI']):
    s = store[n]; S, Z = s['S'], s['Z']
    order = np.argsort(-np.abs(S).mean(0))[:8][::-1]
    for r, j in enumerate(order):
        m = ~np.isnan(Z[:, j]); v = S[m, j]; z = Z[m, j]
        lo, hi = np.nanpercentile(z, [5, 95]); c = np.clip((z - lo) / (hi - lo + 1e-9), 0, 1)
        jit = rng.uniform(-0.28, 0.28, len(v))
        sc = ax.scatter(v, r + jit, c=c, cmap='coolwarm', s=4, alpha=0.7, linewidths=0, rasterized=True)
    labs = [s['labels'][j] if n == 'TIMSS' else pretty(s['F'][j]) for j in order]
    ax.set_yticks(range(len(order)), [l if len(l) < 32 else l[:30] + '…' for l in labs], fontsize=8.5)
    ax.axvline(0, color=INK2, lw=0.8); ax.set_title(n); ax.set_xlabel('SHAP value for At-Risk probability'); ax.grid(axis='y', visible=False)
cb = fig.colorbar(sc, ax=axs, fraction=0.015, pad=0.01); cb.set_ticks([0, 1]); cb.set_ticklabels(['Low', 'High']); cb.set_label('Feature value')
fig.savefig(f'{OUT}/figure16.png'); plt.close(fig)

# ---- Figure: SHAP share vs attention by domain ----
sd = pd.read_csv(f'{X}/shap_domains.csv')
fig, axs = plt.subplots(1, 5, figsize=(14, 3.0), sharey=True)
for ax, (_, n, pth) in zip(axs, DS):
    att = pd.read_csv(f'{pth}/V20_attention_weights.csv').set_index('domain')['overall']
    g = sd[sd.dataset == n].set_index('domain')
    xs = np.arange(4); doms = ['Knowledge', 'Skill', 'Attitude', 'Context']
    ax.bar(xs - 0.19, [g.loc[d, 'shap_share'] for d in doms], 0.36, color=CAT[0], label='SHAP share (Random Forest)')
    ax.bar(xs + 0.19, [att[d] for d in doms], 0.36, color=CAT[1], label='Attention weight (KSA-EADE)')
    ax.set_xticks(xs, ['K', 'S', 'A', 'B']); ax.set_title(n); ax.grid(axis='x', visible=False)
axs[0].set_ylabel('Share of total')
h, l = axs[0].get_legend_handles_labels(); fig.legend(h, l, ncol=2, loc='lower center', bbox_to_anchor=(0.5, -0.1))
fig.tight_layout(); fig.savefig(f'{OUT}/figure17.png'); plt.close(fig)

# ---- Figure: ROC one-vs-rest for KSA-EADE ----
fig, axs = plt.subplots(1, 5, figsize=(15, 3.2), sharey=True)
for ax, (_, n, pth) in zip(axs, DS):
    z = np.load(f'{pth}/stage3_y_DA-CPSO-RF.npz'); y = ylab(pth); pr = z['KSA-EADE|p_fused']
    for c, (bn, col) in enumerate(zip(BANDS, CAT[:3])):
        fpr, tpr, _ = roc_curve(y == c, pr[:, c]); ax.plot(fpr, tpr, color=col, lw=2, label=f'{bn} ({auc(fpr, tpr):.2f})')
    ax.plot([0, 1], [0, 1], color=INK2, lw=0.8, ls='--'); ax.set_title(n); ax.set_xlabel('False positive rate')
    ax.legend(loc='lower right', fontsize=8.5, title='AUROC', title_fontsize=8.5)
axs[0].set_ylabel('True positive rate')
fig.tight_layout(); fig.savefig(f'{OUT}/figure18.png'); plt.close(fig)

# ---- Figure: critical-difference diagrams ----
fr = pd.read_csv(f'{X}/friedman.csv').set_index('test')
def cd_plot(ax, ranks, cd, k, title, hi=None):
    ranks = dict(sorted(ranks.items(), key=lambda t: t[1]))
    ax.set_xlim(0.6, k + 0.4); ax.set_ylim(0.2, 1.08); ax.axis('off')
    ax.hlines(0.78, 1, k, color=INK, lw=1.2)
    for t in range(1, k + 1):
        ax.vlines(t, 0.76, 0.80, color=INK, lw=1); ax.text(t, 0.84, str(t), ha='center', fontsize=9.5)
    ax.hlines(0.97, 1, 1 + cd, color=INK, lw=2.5); ax.text(1 + cd / 2, 0.99, f'CD = {cd:.2f}', ha='center', fontsize=9.5, va='bottom')
    names = list(ranks); half = (len(names) + 1) // 2
    for i, nm in enumerate(names):
        r = ranks[nm]; left = i < half
        yy = 0.62 - (i if left else i - half) * 0.13
        xx = 0.65 if left else k + 0.35
        col = CAT[0] if hi and hi in nm else INK
        ax.plot([r, r, xx], [0.78, yy, yy], color=col, lw=1.6 if col != INK else 1)
        ax.text(xx + (-0.02 if left else 0.02), yy, f'{nm} ({r:.2f})', ha='right' if left else 'left', va='center', fontsize=9.5, color=col,
                fontweight='bold' if col != INK else 'normal')
    # cliques: groups within CD
    cl, yb = [], 0.70
    for i in range(len(names)):
        j = i
        while j + 1 < len(names) and ranks[names[j + 1]] - ranks[names[i]] <= cd: j += 1
        if j > i and not any(a <= i and j <= b for a, b in cl): cl.append((i, j))
    for a, b in cl:
        ax.hlines(yb, ranks[names[a]] - 0.03, ranks[names[b]] + 0.03, color=INK2, lw=4, alpha=0.6); yb -= 0.04
    ax.set_title(title, fontsize=11.5, fontweight='bold', pad=16)
fig, axs = plt.subplots(1, 2, figsize=(13, 2.9), gridspec_kw=dict(width_ratios=[1.6, 1]))
r1 = json.loads(fr.loc['Models (accuracy)', 'ranks']); r1 = {('KSA-EADE (proposed)' if k == 'KSA-EADE' else k): v for k, v in r1.items()}
cd_plot(axs[0], r1, fr.loc['Models (accuracy)', 'CD'], 6, '(a) Prediction models', hi='KSA-EADE')
r2 = json.loads(fr.loc['Wrappers (accuracy)', 'ranks']); r2 = {{'Particle Swarm Optimization': 'PSO', 'Genetic Algorithm': 'Genetic algorithm'}.get(k, 'DA-CPSO-RF (proposed)' if 'DA' in k else k): v for k, v in r2.items()}
cd_plot(axs[1], r2, fr.loc['Wrappers (accuracy)', 'CD'], 3, '(b) Wrapper selectors', hi='DA-CPSO-RF')
fig.tight_layout(); fig.savefig(f'{OUT}/figure19.png'); plt.close(fig)
print('extra figs ok')
