from paths import CODE, DATA, RES
import json
import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold

import os
DATASET = os.environ.get('DATASET', 'timss')
OUT = f'{RES}/out_{DATASET}'
SEED = 20260715
V = 5


def load():
    df = pd.read_csv(f'{OUT}/timss_sgp_analytic.csv' if DATASET == 'timss' else f'{OUT}/analytic.csv')
    meta = json.load(open(f'{OUT}/meta.json'))
    return df, meta


def outer_folds(y):
    return list(StratifiedKFold(V, shuffle=True, random_state=SEED).split(np.zeros(len(y)), y))


class Prep:
    """Fold-internal imputation (mean for continuous/binary, median for ordinal items) and z-scoring."""
    def __init__(self, features, ordinal):
        self.f = features; self.ordinal = set(ordinal)

    def fit(self, X):
        self.fill = {c: (X[c].median() if c in self.ordinal else X[c].mean()) for c in self.f}
        Z = X[self.f].fillna(self.fill)
        self.mu = Z.mean(); self.sd = Z.std(ddof=0).replace(0, 1)
        return self

    def transform(self, X):
        Z = X[self.f].fillna(self.fill)
        return ((Z - self.mu) / self.sd).values.astype(np.float64)
