"""CPU and memory profile of each stage on outer fold 1. One method per process so peak RSS is per method.
Usage: DATASET=x python profile_cpu.py <method>   (prints one JSON line)"""
from paths import CODE, DATA, RES
import os, sys, json, time, resource
os.environ.setdefault('XLA_FLAGS', '--xla_force_host_platform_device_count=1')
import numpy as np
from common import load, outer_folds, Prep, SEED, OUT
method = sys.argv[1]
df, meta = load(); F = meta['features']; y = df['y'].values
folds = outer_folds(y); tr, te = folds[0]
rss0 = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
w0, c0 = time.perf_counter(), time.process_time()
info = {}
if method == 'Stage 1 (preparation)':
    prep = Prep(F, meta['ordinal']).fit(df.iloc[tr]); Xtr, Xte = prep.transform(df.iloc[tr]), prep.transform(df.iloc[te])
elif method in ('DA-CPSO-RF', 'PSO', 'Genetic Algorithm', 'Mutual information', 'ReliefF', 'Boruta', 'RFE (Random Forest)'):
    from fs import binary_pso, baseline_select, DEFAULT
    prep = Prep(F, meta['ordinal']).fit(df.iloc[tr]); Xtr = prep.transform(df.iloc[tr])
    dom_idx = [np.array([i for i, f in enumerate(F) if meta['domain_of'][f] == d]) for d in ['Knowledge', 'Skill', 'Attitude']]
    rng = np.random.default_rng(SEED)
    w0, c0 = time.perf_counter(), time.process_time()
    if method == 'DA-CPSO-RF':
        sel, inf = binary_pso(Xtr, y[tr], dom_idx, rng=rng, seed=SEED, chaotic=True, domain_aware=True); info['evals'] = inf['evals']
    elif method == 'PSO':
        sel, inf = binary_pso(Xtr, y[tr], [], rng=rng, seed=SEED, chaotic=False, domain_aware=False); info['evals'] = inf['evals']
    else:
        sel = baseline_select(method, Xtr, y[tr], DEFAULT['k'], SEED, rng)
    info['k'] = int(len(sel))
else:
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import train_test_split
    from model import train, predict, dirichlet_uncertainty
    sub = json.load(open(f'{OUT}/fs_main.json'))['DA-CPSO-RF'][0]['subset']; fi = [F.index(s) for s in sub]
    prep = Prep(F, meta['ordinal']).fit(df.iloc[tr]); X = prep.transform(df)[:, fi]
    dom = [meta['domain_of'][s] for s in sub]
    blocks = [np.array([i for i, d in enumerate(dom) if d == D]) for D in ['Knowledge', 'Skill', 'Attitude', 'Context'] if D in dom]
    a, b = train_test_split(tr, test_size=0.15, stratify=y[tr], random_state=SEED)
    w0, c0 = time.perf_counter(), time.process_time()
    if method == 'Random Forest (100 trees)':
        m_ = RandomForestClassifier(100, random_state=SEED, n_jobs=1).fit(X[tr], y[tr]); infer = lambda: m_.predict_proba(X[te])
    elif method == 'KSA-EADE':
        p, fwd, _ = train(X[a], y[a], X[b], y[b], blocks, kind='edl', seed=1)
        infer = lambda: dirichlet_uncertainty(predict(p, fwd, X[te], 'edl')[0])
    elif method == 'Softmax MLP':
        p, fwd, _ = train(X[a], y[a], X[b], y[b], blocks, kind='softmax', seed=1); infer = lambda: predict(p, fwd, X[te], 'softmax')
    elif method == 'MC Dropout (50 passes)':
        p, fwd, _ = train(X[a], y[a], X[b], y[b], blocks, kind='softmax', dropout=0.2, seed=1)
        infer = lambda: predict(p, fwd, X[te], 'softmax', passes=50, seed=0)
    elif method == 'Deep Ensemble (3 models)':
        ms = [train(X[a], y[a], X[b], y[b], blocks, kind='softmax', seed=s) for s in (1, 2, 3)]
        infer = lambda: [predict(p, fwd, X[te], 'softmax') for p, fwd, _ in ms]
    t1 = (time.perf_counter(), time.process_time())
    info['train_wall'] = t1[0] - w0; info['train_cpu'] = t1[1] - c0
    infer()
    ci = time.process_time(); wi = time.perf_counter()
    for _ in range(10): infer()
    info['infer_cpu_ms_per_learner'] = (time.process_time() - ci) / 10 / len(te) * 1000
    info['infer_wall_ms_per_learner'] = (time.perf_counter() - wi) / 10 / len(te) * 1000
w1, c1 = time.perf_counter(), time.process_time()
rss1 = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
print(json.dumps(dict(dataset=os.environ.get('DATASET', 'timss'), method=method, wall_s=w1 - w0, cpu_s=c1 - c0,
                      cpu_util=(c1 - c0) / max(w1 - w0, 1e-9), peak_rss_mb=rss1 / 1024, rss_increase_mb=(rss1 - rss0) / 1024, **info)))
