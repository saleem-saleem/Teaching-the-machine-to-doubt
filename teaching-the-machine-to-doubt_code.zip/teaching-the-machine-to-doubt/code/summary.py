"""Cross-dataset summary from the per-dataset table CSVs."""
from paths import CODE, DATA, RES
import json
import numpy as np, pandas as pd

DS = [('timss', 'TIMSS 2023 Singapore (Grade 8)', f'{RES}/out_timss'),
      ('dropout', 'UCI Dropout and Academic Success', f'{RES}/out_dropout'),
      ('por', 'UCI Student Performance (Portuguese)', f'{RES}/out_por'),
      ('mat', 'UCI Student Performance (Mathematics)', f'{RES}/out_mat'),
      ('xapi', 'xAPI-Edu-Data', f'{RES}/out_xapi')]


def g(path, f):
    return pd.read_csv(f'{path}/{f}.csv')


def num(s):
    return float(str(s).split(' ')[0])


rows, srows, crows, mrows = [], [], [], []
for key, name, p in DS:
    meta = json.load(open(f'{p}/meta.json'))
    an = pd.read_csv(f'{p}/timss_sgp_analytic.csv' if key == 'timss' else f'{p}/analytic.csv')
    y = an['y'].values
    s1 = g(p, 'V1_stage1_measurement') if key != 'timss' else pd.read_csv(f'{p}/T_stage1_measurement.csv')
    sel = g(p, 'V5_selection_stability'); mc = g(p, 'V9_model_comparison'); cal = g(p, 'V11_calibration_fused')
    md = g(p, 'V13_misclassification_detection'); cu = g(p, 'V16_cumulative_pipeline'); ab = g(p, 'V7_search_ablation')
    sens = g(p, 'V8_sensitivity')
    da = sel[sel.method.str.startswith('DA-CPSO')].iloc[0]; others = sel[~sel.method.str.startswith('DA-CPSO')]
    filt = others[~others.method.isin(['Genetic Algorithm', 'Particle Swarm Optimization']) & (others.subset_size.map(lambda z: float(str(z).split(' ')[0])) >= 15)]
    rows.append(dict(dataset=name, N=len(y), features=len(meta['features']),
                     classes='/'.join(f'{(y == c).mean() * 100:.0f}' for c in range(3)), majority=round(np.bincount(y).max() / len(y), 3),
                     KMO_range=f"{s1.KMO.min():.2f}–{s1.KMO.max():.2f}", domains_pass_KMO=f"{(s1.KMO >= 0.70).sum()}/3"))
    srows.append(dict(dataset=name, DA_CPSO_RF_kuncheva=round(da.kuncheva, 3), PSO_kuncheva=round(float(others[others.method == 'Particle Swarm Optimization'].kuncheva.iloc[0]), 3),
                      best_other_kuncheva=f"{filt.kuncheva.max():.3f} ({filt.loc[filt.kuncheva.idxmax(), 'method']})",
                      DA_CPSO_RF_acc=num(da.accuracy), best_other_acc=f"{max(num(a) for a in others.accuracy):.3f} ({others.loc[others.accuracy.map(num).idxmax(), 'method']})",
                      RF_all_features_acc=num(cu.loc[0, 'accuracy']),
                      kmin6_kuncheva=round(float(sens.loc[(sens.parameter == 'kmin') & (sens.value.astype(str).str.startswith('6')), 'kuncheva'].iloc[0]), 3) if ((sens.parameter == 'kmin').any()) else None))
    ke = mc[mc.model == 'KSA-EADE + RF fusion'].iloc[0]
    base = mc[mc.model.str.contains(r'\+ RF fusion') & ~mc.model.str.startswith('KSA')]
    best = base.loc[base.accuracy.map(num).idxmax()]
    kc = cal[cal.model == 'KSA-EADE + RF fusion'].iloc[0]; bc = cal[~cal.model.str.startswith(('KSA', 'RF'))]
    crows.append(dict(dataset=name, KSA_EADE_acc=num(ke.accuracy), best_baseline_acc=f"{num(best.accuracy):.3f} ({best.model.replace(' + RF fusion', '')})",
                      KSA_EADE_macroF1=ke.macro_f1, best_baseline_macroF1=round(base.macro_f1.max(), 3),
                      KSA_EADE_ECE=kc.ECE, baseline_ECE_range=f"{bc.ECE.min():.3f}–{bc.ECE.max():.3f}",
                      rho=ke.rho_per_fold, min_p_vs_baselines=round(float(base.p_value.min()), 3)))
    mrows.append(dict(dataset=name, err_auroc_total=md.loc[0, 'AUROC'], err_auroc_maxprob=md.loc[4, 'AUROC'],
                      KSA_EADE_no_fusion_acc=num(mc[mc.model == 'KSA-EADE (no fusion)'].accuracy.iloc[0]),
                      softmax_no_fusion_acc=num(mc[mc.model == 'Softmax MLP (no fusion)'].accuracy.iloc[0])))
S = dict(S1_datasets=pd.DataFrame(rows), S2_selection=pd.DataFrame(srows), S3_prediction=pd.DataFrame(crows), S4_uncertainty=pd.DataFrame(mrows))
for k, d in S.items():
    d.to_csv(f'{RES}/{k}.csv', index=False); print('\n==', k); print(d.to_string(index=False))
