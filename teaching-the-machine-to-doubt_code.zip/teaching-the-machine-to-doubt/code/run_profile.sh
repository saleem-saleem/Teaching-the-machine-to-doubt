#!/bin/sh
# CPU and memory profile of every method on outer fold 1 (one process per method).
cd "$(dirname "$0")"
OUTF=../results/cpu_profile.jsonl; : > $OUTF
for ds in timss dropout por mat xapi; do
 for m in "Stage 1 (preparation)" "DA-CPSO-RF" "PSO" "Genetic Algorithm" "Boruta" "ReliefF" "RFE (Random Forest)" "Mutual information" "Random Forest (100 trees)" "KSA-EADE" "Softmax MLP" "MC Dropout (50 passes)" "Deep Ensemble (3 models)"; do
   DATASET=$ds OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 python3 profile_cpu.py "$m" 2>/dev/null | tail -1 >> $OUTF
 done
done
