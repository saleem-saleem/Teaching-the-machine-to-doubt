"""Stage 3: KSA-EADE and same-backbone baselines, implemented in JAX."""
import time
import numpy as np
import jax
import jax.numpy as jnp
from jax.scipy.special import gammaln, digamma

C = 3
HP = dict(h=32, H=64, lr=1e-3, batch=64, epochs=200, patience=20, l2=1e-4, anneal=10, dropout=0.2)


def add1(x):
    return jnp.concatenate([x, jnp.ones(x.shape[:-1] + (1,))], axis=-1)


def init_params(key, blocks, k, hp, attention=True, partition=True):
    h, H = hp['h'], hp['H']
    keys = jax.random.split(key, 8)
    def glorot(k_, shape):
        lim = np.sqrt(6 / (shape[0] + shape[1])); return jax.random.uniform(k_, shape, minval=-lim, maxval=lim)
    p = {}
    if partition:
        p['W'] = [glorot(jax.random.fold_in(keys[0], i), (len(b) + 1, h)) for i, b in enumerate(blocks)]
    else:
        p['W'] = [glorot(keys[0], (k + 1, h))]
    if attention and partition:
        p['q'] = glorot(keys[1], (h, 1))[:, 0]
    p['W1'] = glorot(keys[2], (h + 1, H)); p['W2'] = glorot(keys[3], (H + 1, H)); p['We'] = glorot(keys[4], (H + 1, C))
    return p


def n_params(p):
    return int(sum(np.prod(x.shape) for x in jax.tree_util.tree_leaves(p)))


def make_forward(blocks, attention=True, partition=True, dropout=0.0):
    def forward(p, X, key=None):
        if partition:
            Hs = jnp.stack([jnp.tanh(add1(X[:, b]) @ W) for b, W in zip(blocks, p['W'])], axis=1)  # n x D x h
            if attention:
                a = jax.nn.softmax(Hs @ p['q'], axis=1)               # n x D
            else:
                a = jnp.ones(Hs.shape[:2]) / Hs.shape[1]
            hbar = (a[:, :, None] * Hs).sum(axis=1)
        else:
            hbar = jnp.tanh(add1(X) @ p['W'][0]); a = jnp.ones((X.shape[0], 1))
        g1 = jax.nn.relu(add1(hbar) @ p['W1'])
        if dropout > 0 and key is not None:
            k1, k2 = jax.random.split(key)
            g1 = g1 * jax.random.bernoulli(k1, 1 - dropout, g1.shape) / (1 - dropout)
        g2 = jax.nn.relu(add1(g1) @ p['W2'])
        if dropout > 0 and key is not None:
            g2 = g2 * jax.random.bernoulli(k2, 1 - dropout, g2.shape) / (1 - dropout)
        out = add1(g2) @ p['We']
        return out, a
    return forward


def edl_loss(out, Y, epoch, anneal):
    e = jax.nn.relu(out); alpha = e + 1; S = alpha.sum(-1, keepdims=True); ph = alpha / S
    mse = ((Y - ph) ** 2 + ph * (1 - ph) / (S + 1)).sum(-1)
    at = Y + (1 - Y) * alpha; St = at.sum(-1)
    kl = gammaln(St) - gammaln(float(C)) - gammaln(at).sum(-1) + ((at - 1) * (digamma(at) - digamma(St)[:, None])).sum(-1)
    return (mse + jnp.minimum(1.0, epoch / anneal) * kl).mean()


def ce_loss(out, Y, epoch, anneal):
    return -(Y * jax.nn.log_softmax(out)).sum(-1).mean()


def l2(p):
    return sum((w ** 2).sum() for w in jax.tree_util.tree_leaves(p))


def adam_init(p):
    z = jax.tree_util.tree_map(jnp.zeros_like, p); return (z, z, 0)


def train(Xtr, ytr, Xva, yva, blocks, kind='edl', attention=True, partition=True, dropout=0.0, seed=0, hp=HP):
    """kind: 'edl' (evidential) or 'softmax'. Returns params, forward fn, info."""
    key = jax.random.PRNGKey(seed)
    p = init_params(key, blocks, Xtr.shape[1], hp, attention, partition)
    fwd = make_forward(blocks, attention, partition, dropout)
    lossf = edl_loss if kind == 'edl' else ce_loss
    Ytr = jax.nn.one_hot(ytr, C); Xtr_j = jnp.asarray(Xtr); Xva_j = jnp.asarray(Xva)

    def total(p, X, Y, epoch, key):
        out, _ = fwd(p, X, key)
        return lossf(out, Y, epoch, hp['anneal']) + hp['l2'] * l2(p)

    @jax.jit
    def step(p, m, v, t, X, Y, epoch, key):
        g = jax.grad(total)(p, X, Y, epoch, key)
        t = t + 1; b1, b2 = 0.9, 0.999
        m = jax.tree_util.tree_map(lambda a, b: b1 * a + (1 - b1) * b, m, g)
        v = jax.tree_util.tree_map(lambda a, b: b2 * a + (1 - b2) * b * b, v, g)
        p = jax.tree_util.tree_map(lambda w, a, b: w - hp['lr'] * (a / (1 - b1 ** t)) / (jnp.sqrt(b / (1 - b2 ** t)) + 1e-8), p, m, v)
        return p, m, v, t

    @jax.jit
    def val_nll(p):
        out, _ = fwd(p, Xva_j)
        pr = probs(out, kind)
        return -jnp.log(jnp.clip(pr[jnp.arange(len(yva)), yva], 1e-12)).mean()

    m, v, t = adam_init(p)
    rng = np.random.default_rng(seed)
    best, bestp, wait, ep_best = np.inf, p, 0, 0
    t0 = time.time()
    for ep in range(hp['epochs']):
        idx = rng.permutation(len(ytr))
        for s in range(0, len(idx), hp['batch']):
            b = idx[s:s + hp['batch']]
            key, sub = jax.random.split(key)
            p, m, v, t = step(p, m, v, t, Xtr_j[b], Ytr[b], float(ep), sub if dropout > 0 else None)
        vl = float(val_nll(p))
        if ep < hp['anneal'] and kind == 'edl':
            continue
        if vl < best - 1e-5:
            best, bestp, wait, ep_best = vl, p, 0, ep
        else:
            wait += 1
            if wait >= hp['patience']: break
    return bestp, fwd, dict(epochs=ep + 1, best_epoch=ep_best, train_seconds=time.time() - t0, val_nll=best)


def probs(out, kind):
    if kind == 'edl':
        a = jax.nn.relu(out) + 1; return a / a.sum(-1, keepdims=True)
    return jax.nn.softmax(out)


def predict(p, fwd, X, kind, passes=1, seed=0, dropout=0.0):
    X = jnp.asarray(X)
    if passes == 1:
        out, a = fwd(p, X)
        return np.asarray(out), np.asarray(a)
    outs = []
    key = jax.random.PRNGKey(seed + 999)
    for i in range(passes):
        key, sub = jax.random.split(key)
        o, a = fwd(p, X, sub); outs.append(np.asarray(o))
    return np.stack(outs), np.asarray(a)


def dirichlet_uncertainty(out):
    e = np.maximum(out, 0); alpha = e + 1; S = alpha.sum(-1, keepdims=True); ph = alpha / S
    Ht = -(ph * np.log(ph)).sum(-1)
    from scipy.special import digamma as dg
    Al = (ph * (dg(S + 1) - dg(alpha + 1))).sum(-1)
    return dict(p=ph, total=Ht, aleatoric=Al, epistemic=Ht - Al, vacuity=(C / S)[:, 0], strength=S[:, 0])


def entropy(p):
    q = np.clip(p, 1e-12, 1); return -(q * np.log(q)).sum(-1)


def macs(k, blocks_n, hp=HP, partition=True, attention=True, members=1):
    h, H = hp['h'], hp['H']
    emb = h * k if partition else h * k
    att = blocks_n * h * 2 if (attention and partition) else 0
    return members * (emb + att + h * H + H * H + H * C)
