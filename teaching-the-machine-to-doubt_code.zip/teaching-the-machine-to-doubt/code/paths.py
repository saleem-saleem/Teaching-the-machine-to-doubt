"""Repository paths. Data go in ../data, all outputs in ../results."""
import os
CODE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(CODE)
DATA = os.path.join(ROOT, 'data')
RES = os.path.join(ROOT, 'results')
os.makedirs(RES, exist_ok=True)
