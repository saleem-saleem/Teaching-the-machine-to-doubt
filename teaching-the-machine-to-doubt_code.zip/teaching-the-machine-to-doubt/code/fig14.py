from paths import CODE, DATA, RES
import json, numpy as np, pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
exec(open(f'{CODE}/res_figs.py').read().split('# ---- Figure 6')[0])
P = pd.DataFrame([json.loads(l) for l in open(f'{RES}/cpu_profile.jsonl') if l.startswith('{')])
MM = [('KSA-EADE', 'KSA-EADE\n(proposed)'), ('Softmax MLP', 'Softmax\nMLP'), ('MC Dropout (50 passes)', 'MC Dropout\n(50 passes)'),
      ('Deep Ensemble (3 models)', 'Deep\nEnsemble'), ('Random Forest (100 trees)', 'Random\nForest')]
fig, axs = plt.subplots(1, 2, figsize=(10, 3.6))
for ax, col, title, yl in [(axs[0], 'train_cpu', '(a) Training CPU time per fold', 'CPU seconds'),
                           (axs[1], 'infer_cpu_ms_per_learner', '(b) Inference CPU time per learner', 'CPU milliseconds (log scale)')]:
    for i, (m, lab) in enumerate(MM):
        v = P[P.method == m][col].values
        ax.bar(i, v.mean(), 0.62, color=CAT[0] if i == 0 else '#9c9b96', zorder=2)
        ax.scatter(np.full(len(v), i) + np.linspace(-0.18, 0.18, len(v)), v, s=16, color=INK, zorder=3)
        if not col.startswith('infer') and v.mean() < 2:
            ax.text(i, v.mean() + 0.9, f'{v.mean():.1f}', ha='center', va='bottom', fontsize=9.5, color=INK, fontweight='bold'); continue
        ax.text(i, 0.0125 if col.startswith('infer') else 0.4, f'{v.mean():.2g}' if col.startswith('infer') else f'{v.mean():.1f}', ha='center', va='bottom', fontsize=9.5, color='#ffffff', fontweight='bold', zorder=4)
    ax.set_xticks(range(len(MM)), [lab for _, lab in MM], fontsize=9.5); ax.set_title(title); ax.set_ylabel(yl); ax.grid(axis='x', visible=False)
axs[1].set_yscale('log'); axs[1].set_ylim(0.008, 10)
fig.tight_layout(); fig.savefig(f'{RES}/figures/figure14.png'); print('fig14 ok')
