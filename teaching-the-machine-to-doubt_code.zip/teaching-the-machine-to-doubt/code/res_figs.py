"""Result figures (Figures 6-14) for the Results section."""
from paths import CODE, DATA, RES
import json, os
import numpy as np, pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager

OUT = f'{RES}/figures'; os.makedirs(OUT, exist_ok=True)
plt.rcParams.update({'font.family': 'Liberation Sans', 'font.size': 10.5, 'axes.titlesize': 11.5, 'axes.titleweight': 'bold',
                     'axes.labelsize': 10.5, 'axes.spines.top': False, 'axes.spines.right': False, 'axes.edgecolor': '#52514e',
                     'axes.linewidth': 0.8, 'xtick.color': '#52514e', 'ytick.color': '#52514e', 'axes.labelcolor': '#0b0b0b',
                     'legend.frameon': False, 'savefig.dpi': 300, 'savefig.bbox': 'tight', 'axes.grid': True,
                     'grid.color': '#e4e3df', 'grid.linewidth': 0.6, 'axes.axisbelow': True})
CAT = ['#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4', '#008300', '#6250d6', '#e34948']
INK, INK2 = '#0b0b0b', '#52514e'
DS = [('timss', 'TIMSS', f'{RES}/out_timss'), ('dropout', 'Dropout', f'{RES}/out_dropout'),
      ('por', 'Portuguese', f'{RES}/out_por'), ('mat', 'Mathematics', f'{RES}/out_mat'),
      ('xapi', 'xAPI', f'{RES}/out_xapi')]
BANDS = ['At-Risk', 'Moderate', 'High']


def ylab(d):
    f = f'{d}/timss_sgp_analytic.csv' if d.endswith('/out_timss') else f'{d}/analytic.csv'
    return pd.read_csv(f)['y'].values


def save(fig, n):
    fig.savefig(f'{OUT}/figure{n}.png'); plt.close(fig)


# ---- Figure 6: KMO by domain ----
fig, ax = plt.subplots(figsize=(7.2, 3.4))
x = np.arange(5); w = 0.26
for j, dom in enumerate(['Knowledge', 'Skill', 'Attitude']):
    v = [pd.read_csv(f'{p}/V1_stage1_measurement.csv').set_index('domain').loc[dom, 'KMO'] for _, _, p in DS]
    b = ax.bar(x + (j - 1) * w, v, w - 0.03, color=CAT[j], label=dom)
    for xi, vi in zip(x + (j - 1) * w, v): ax.text(xi, vi + 0.012, f'{vi:.2f}', ha='center', va='bottom', fontsize=8.5, color=INK2, zorder=5, bbox=dict(boxstyle='square,pad=0.08', fc='white', ec='none'))
ax.axhline(0.70, color=INK, lw=1.2, ls='--', zorder=1); ax.text(4.55, 0.735, 'Adequacy threshold (0.70)', ha='right', va='bottom', fontsize=9, color=INK)
ax.set_xticks(x, [n for _, n, _ in DS]); ax.set_ylabel('KMO index'); ax.set_ylim(0, 1.05)
ax.legend(ncol=3, loc='upper center', bbox_to_anchor=(0.5, 1.13)); ax.grid(axis='x', visible=False)
save(fig, 6)

# ---- Figure 7: convergence ----
fig, axs = plt.subplots(1, 5, figsize=(11, 2.9), sharex=True)
for ax, (_, n, p) in zip(axs, DS):
    a = np.mean([r['hist'] for r in json.load(open(f'{p}/fs_main.json'))['DA-CPSO-RF']], 0)
    b = np.mean([r['hist'] for r in json.load(open(f'{p}/fs_pso.json'))['PSO']], 0)
    ax.plot(range(len(b)), b, color=CAT[1], lw=2, marker='s', ms=3.5, label='PSO')
    ax.plot(range(len(a)), a, color=CAT[0], lw=2, marker='o', ms=3.5, label='DA-CPSO-RF')
    ax.set_title(n); ax.set_xlabel('Iteration'); ax.set_xticks([0, 7, 14])
axs[0].set_ylabel('Best fitness (mean of folds)')
axs[0].legend(loc='lower right', fontsize=9)
fig.tight_layout(); save(fig, 7)

# ---- Figure 8: domain floor ----
fig, axs = plt.subplots(1, 2, figsize=(8.6, 3.3))
sel = [d for d in DS if d[0] != 'mat']
for j, (_, n, p) in enumerate(sel):
    s = pd.read_csv(f'{p}/V8_sensitivity.csv'); ref = s.iloc[0]
    k2 = s[(s.parameter == 'kmin') & (s.value == 2)].iloc[0]; k6 = s[(s.parameter == 'kmin') & (s.value == 6)].iloc[0]
    ks = [k2.kuncheva, ref.kuncheva, k6.kuncheva]; ac = [float(str(r.accuracy).split()[0]) for r in (k2, ref, k6)]
    axs[0].plot([2, 4, 6], ks, color=CAT[j], lw=2, marker='o', ms=6, label=n)
    axs[1].plot([2, 4, 6], ac, color=CAT[j], lw=2, marker='o', ms=6, label=n)
    axs[0].text(6.12, ks[2], n, va='center', fontsize=9, color=INK)
    axs[1].text(6.12, ac[2], n, va='center', fontsize=9, color=INK)
axs[0].set_title('(a) Selection stability'); axs[0].set_ylabel('Kuncheva index')
axs[1].set_title('(b) Random Forest accuracy'); axs[1].set_ylabel('Accuracy')
for ax in axs: ax.set_xticks([2, 4, 6]); ax.set_xlabel('Minimum features per domain ($k_{min}$)'); ax.set_xlim(1.6, 7.6)
fig.tight_layout(); h, l = axs[0].get_legend_handles_labels(); fig.legend(h, l, ncol=4, loc='lower center', bbox_to_anchor=(0.5, -0.08), fontsize=9.5); save(fig, 8)

# ---- Figure 9: model accuracy (dot plot) ----
MODELS = [('KSA-EADE + RF fusion', 'KSA-EADE (proposed)'), ('RF', 'Random Forest'), ('Softmax MLP + RF fusion', 'Softmax MLP'),
          ('MC Dropout (50 passes) + RF fusion', 'MC Dropout'), ('Temperature Scaling + RF fusion', 'Temperature Scaling'),
          ('Deep Ensemble (3 models) + RF fusion', 'Deep Ensemble')]
fig, axs = plt.subplots(1, 5, figsize=(11.5, 3.2), sharey=True)
for ax, (_, n, p) in zip(axs, DS):
    t = pd.read_csv(f'{p}/V9_model_comparison.csv').set_index('model')
    for i, (m, lab) in enumerate(MODELS):
        mu, sd = [float(v) for v in t.loc[m, 'accuracy'].split(' ± ')]
        yv = len(MODELS) - 1 - i
        ax.errorbar(mu, yv, xerr=sd, fmt='o', color=CAT[0] if i == 0 else INK2, ms=7 if i == 0 else 5.5, capsize=3, lw=1.2,
                    mfc=CAT[0] if i == 0 else '#ffffff', mew=1.6)
    ax.set_title(n); ax.set_xlabel('Accuracy'); ax.grid(axis='y', visible=False)
    ax.xaxis.set_major_locator(plt.MaxNLocator(3))
axs[0].set_yticks(range(len(MODELS)), [lab for _, lab in MODELS][::-1])
fig.tight_layout(); save(fig, 9)

# ---- Figure 10: confusion matrices ----
fig, axs = plt.subplots(1, 5, figsize=(12, 2.9))
for ax, (_, n, p) in zip(axs, DS):
    z = np.load(f'{p}/stage3_y_DA-CPSO-RF.npz'); y = ylab(p); pr = z['KSA-EADE|p_fused'].argmax(1)
    cm = np.zeros((3, 3)); np.add.at(cm, (y, pr), 1); r = cm / cm.sum(1, keepdims=True)
    ax.imshow(r, cmap='Blues', vmin=0, vmax=1)
    for i in range(3):
        for j in range(3):
            ax.text(j, i, f'{r[i, j]:.2f}\n({int(cm[i, j])})', ha='center', va='center', fontsize=8.5,
                    color='#ffffff' if r[i, j] > 0.55 else INK)
    ax.set_xticks(range(3), ['Risk', 'Mod.', 'High']); ax.set_yticks(range(3), ['Risk', 'Mod.', 'High'])
    ax.set_title(n); ax.set_xlabel('Predicted'); ax.grid(False)
axs[0].set_ylabel('True band')
fig.tight_layout(); save(fig, 10)

# ---- Figure 11: selective prediction ----
fig, axs = plt.subplots(1, 2, figsize=(9.2, 3.4))
for j, (_, n, p) in enumerate(DS):
    s = pd.read_csv(f'{p}/V14_selective_prediction.csv')
    axs[0].plot(s.coverage * 100, s.accuracy, color=CAT[j], lw=2, marker='o', ms=5, label=n)
    axs[1].plot(s.coverage * 100, s.at_risk_recall, color=CAT[j], lw=2, marker='o', ms=5, label=n)
for ax, t, yl in [(axs[0], '(a) Accuracy on retained learners', 'Accuracy'), (axs[1], '(b) At-Risk recall on retained learners', 'At-Risk recall')]:
    ax.set_title(t); ax.set_xlabel('Coverage (% of learners kept)'); ax.set_ylabel(yl); ax.invert_xaxis()
axs[1].legend(loc='center left', bbox_to_anchor=(1.02, 0.5), fontsize=9)
fig.tight_layout(); save(fig, 11)

# ---- Figure 12: uncertainty for correct vs incorrect ----
fig, ax = plt.subplots(figsize=(8.2, 3.3))
pos = []
for j, (_, n, p) in enumerate(DS):
    z = np.load(f'{p}/stage3_y_DA-CPSO-RF.npz'); y = ylab(p); pr = z['KSA-EADE|p_fused'].argmax(1); u = z['KSA-EADE|total']
    for k, (mask, col) in enumerate([(pr == y, CAT[0]), (pr != y, CAT[1])]):
        bp = ax.boxplot(u[mask], positions=[j * 3 + k], widths=0.7, patch_artist=True, showfliers=False,
                        medianprops=dict(color=INK, lw=1.5), whiskerprops=dict(color=INK2), capprops=dict(color=INK2))
        bp['boxes'][0].set(facecolor=col, edgecolor=INK2, alpha=0.9)
ax.set_xticks([j * 3 + 0.5 for j in range(5)], [n for _, n, _ in DS]); ax.set_ylabel('Total uncertainty $u_i$')
ax.grid(axis='x', visible=False)
from matplotlib.patches import Patch
ax.legend(handles=[Patch(color=CAT[0], label='Correct prediction'), Patch(color=CAT[1], label='Incorrect prediction')],
          ncol=2, loc='upper center', bbox_to_anchor=(0.5, 1.14))
save(fig, 12)

# ---- Figure 13: attention heatmaps ----
fig, axs = plt.subplots(1, 5, figsize=(12, 2.8))
for ax, (_, n, p) in zip(axs, DS):
    t = pd.read_csv(f'{p}/V20_attention_weights.csv').set_index('domain')[BANDS]
    t.index = ['Knowledge', 'Skill', 'Attitude', 'Background']
    ax.imshow(t.values, cmap='Blues', vmin=0, vmax=0.55, aspect='auto')
    for i in range(4):
        for j in range(3):
            v = t.values[i, j]; ax.text(j, i, f'{v:.2f}', ha='center', va='center', fontsize=9, color='#ffffff' if v > 0.33 else INK)
    ax.set_xticks(range(3), ['Risk', 'Mod.', 'High']); ax.set_yticks(range(4), t.index if ax is axs[0] else [''] * 4)
    ax.set_title(n); ax.grid(False)
fig.tight_layout(); save(fig, 13)
print('figs ok')
