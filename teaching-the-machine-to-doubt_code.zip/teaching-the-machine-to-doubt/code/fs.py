"""Stage 2: DA-CPSO-RF and baseline feature selectors."""
import time
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.feature_selection import mutual_info_classif, chi2, RFE
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import MinMaxScaler

DEFAULT = dict(P=12, T=14, w=0.72, c1=1.5, c2=1.5, vmax=0.6, mu=4.0, k=20, kmin=4, beta=0.88, ntree=20, K_in=3)


class Fitness:
    def __init__(self, X, y, beta, ntree, K_in, seed):
        self.X, self.y, self.beta, self.ntree = X, y, beta, ntree
        self.cv = list(StratifiedKFold(K_in, shuffle=True, random_state=seed).split(X, y))
        self.cache = {}; self.seed = seed; self.L = X.shape[1]; self.evals = 0

    def acc(self, b):
        key = b.tobytes()
        if key not in self.cache:
            idx = np.flatnonzero(b)
            if len(idx) == 0:
                self.cache[key] = 0.0
            else:
                s = []
                for tr, va in self.cv:
                    rf = RandomForestClassifier(self.ntree, random_state=self.seed, n_jobs=1)
                    rf.fit(self.X[tr][:, idx], self.y[tr]); s.append(rf.score(self.X[va][:, idx], self.y[va]))
                self.cache[key] = float(np.mean(s)); self.evals += 1
        return self.cache[key]

    def __call__(self, b):
        return self.beta * self.acc(b) + (1 - self.beta) * (1 - b.sum() / self.L)


def logistic_sequence(n, mu, c0, burn=100):
    c = c0; out = np.empty(n)
    for _ in range(burn): c = mu * c * (1 - c)
    for i in range(n):
        c = mu * c * (1 - c); out[i] = c
    return out


def repair(b, v, dom_idx, k, kmin, domain_aware):
    b = b.copy()
    if domain_aware:
        for idx in dom_idx:
            sel = idx[b[idx] == 1]; kd = min(kmin, len(idx))
            if len(sel) < kd:
                cand = idx[b[idx] == 0]
                add = cand[np.argsort(-v[cand])][:kd - len(sel)]
                b[add] = 1
    while b.sum() > k:
        sel = np.flatnonzero(b)
        order = sel[np.argsort(v[sel])]
        for j in order:
            if domain_aware:
                d = [idx for idx in dom_idx if j in idx]
                if d and b[d[0]].sum() <= min(kmin, len(d[0])):
                    continue
            b[j] = 0; break
        else:
            break
    if b.sum() == 0:
        b[np.argmax(v)] = 1
    return b


def binary_pso(X, y, dom_idx, cfg=None, chaotic=True, domain_aware=True, rng=None, seed=None):
    cfg = {**DEFAULT, **(cfg or {})}
    P, T, L = cfg['P'], cfg['T'], X.shape[1]
    fit = Fitness(X, y, cfg['beta'], cfg['ntree'], cfg['K_in'], seed)
    if chaotic:
        c0 = 0.05 + 0.9 * np.random.default_rng(seed).random()
        while min(abs(c0 - q) for q in (0.25, 0.5, 0.75)) < 1e-3: c0 += 0.01
        seq = logistic_sequence(2 * P * L, cfg['mu'], c0)
        B = (seq[:P * L].reshape(P, L) > 0.5).astype(np.int8)
        Vel = cfg['vmax'] * (2 * seq[P * L:].reshape(P, L) - 1)
    else:
        B = (rng.random((P, L)) > 0.5).astype(np.int8)
        Vel = rng.uniform(-cfg['vmax'], cfg['vmax'], (P, L))
    B = np.array([repair(B[i], Vel[i], dom_idx, cfg['k'], cfg['kmin'], domain_aware) for i in range(P)])
    F = np.array([fit(b) for b in B])
    PB, PF = B.copy(), F.copy()
    g = int(np.argmax(PF)); GB, GF = PB[g].copy(), PF[g]; conv = 0; hist = [GF]
    for t in range(T):
        r1, r2 = rng.random((P, L)), rng.random((P, L))
        Vel = cfg['w'] * Vel + cfg['c1'] * r1 * (PB - B) + cfg['c2'] * r2 * (GB - B)
        Vel = np.clip(Vel, -cfg['vmax'], cfg['vmax'])
        B = (rng.random((P, L)) < 1 / (1 + np.exp(-Vel))).astype(np.int8)
        B = np.array([repair(B[i], Vel[i], dom_idx, cfg['k'], cfg['kmin'], domain_aware) for i in range(P)])
        F = np.array([fit(b) for b in B])
        imp = F > PF; PB[imp], PF[imp] = B[imp], F[imp]
        g = int(np.argmax(PF))
        if PF[g] > GF: GB, GF, conv = PB[g].copy(), PF[g], t + 1
        hist.append(GF)
    return np.flatnonzero(GB), dict(conv=conv, fitness=GF, acc_in=fit.acc(GB), evals=fit.evals, hist=hist)


def genetic(X, y, cfg=None, rng=None, seed=None):
    cfg = {**DEFAULT, **(cfg or {})}
    P, T, L, k = cfg['P'], cfg['T'], X.shape[1], cfg['k']
    fit = Fitness(X, y, cfg['beta'], cfg['ntree'], cfg['K_in'], seed)

    def cap(b):
        while b.sum() > k:
            b[rng.choice(np.flatnonzero(b))] = 0
        if b.sum() == 0: b[rng.integers(L)] = 1
        return b
    pop = np.array([cap((rng.random(L) > 0.5).astype(np.int8)) for _ in range(P)])
    F = np.array([fit(b) for b in pop])
    best, bf, conv = pop[np.argmax(F)].copy(), F.max(), 0
    for t in range(T):
        new = [best.copy()]
        while len(new) < P:
            a, b_ = [pop[max(rng.choice(P, 2, replace=False), key=lambda i: F[i])] for _ in range(2)]
            child = np.where(rng.random(L) < 0.5, a, b_) if rng.random() < 0.8 else a.copy()
            flip = rng.random(L) < 1 / L; child = np.where(flip, 1 - child, child).astype(np.int8)
            new.append(cap(child))
        pop = np.array(new); F = np.array([fit(b) for b in pop])
        if F.max() > bf: best, bf, conv = pop[np.argmax(F)].copy(), F.max(), t + 1
    return np.flatnonzero(best), dict(conv=conv, fitness=bf)


def mrmr(X, y, k, seed):
    rel = mutual_info_classif(X, y, random_state=seed)
    C = np.abs(np.corrcoef(X, rowvar=False))
    sel = [int(np.argmax(rel))]
    while len(sel) < k:
        rest = [j for j in range(X.shape[1]) if j not in sel]
        score = [rel[j] - C[j, sel].mean() for j in rest]
        sel.append(rest[int(np.argmax(score))])
    return np.array(sorted(sel))


def baseline_select(name, X, y, k, seed, rng):
    if name == 'Mutual information':
        return np.sort(np.argsort(-mutual_info_classif(X, y, random_state=seed))[:k])
    if name == 'Chi-square':
        s, _ = chi2(MinMaxScaler().fit_transform(X), y); return np.sort(np.argsort(-s)[:k])
    if name == 'ReliefF':
        from skrebate import ReliefF
        r = ReliefF(n_features_to_select=k, n_neighbors=50, n_jobs=1).fit(X, y)
        return np.sort(np.argsort(-r.feature_importances_)[:k])
    if name == 'mRMR':
        return mrmr(X, y, k, seed)
    if name == 'RFE (Random Forest)':
        r = RFE(RandomForestClassifier(100, random_state=seed, n_jobs=1), n_features_to_select=k, step=2).fit(X, y)
        return np.flatnonzero(r.support_)
    if name == 'LASSO (L1)':
        m = LogisticRegression(penalty='l1', solver='saga', C=0.05, max_iter=3000, random_state=seed).fit(X, y)
        return np.sort(np.argsort(-np.linalg.norm(m.coef_, axis=0))[:k])
    if name == 'Random Forest importance':
        rf = RandomForestClassifier(100, random_state=seed, n_jobs=1).fit(X, y)
        return np.sort(np.argsort(-rf.feature_importances_)[:k])
    if name == 'Boruta':
        from boruta import BorutaPy
        rf = RandomForestClassifier(100, max_depth=7, random_state=seed, n_jobs=1)
        bp = BorutaPy(rf, n_estimators='auto', random_state=seed, max_iter=50, verbose=0).fit(X, y)
        rank = np.lexsort((-bp.ranking_ * 0, bp.ranking_))
        conf = np.flatnonzero(bp.support_)
        if len(conf) > k:
            imp = RandomForestClassifier(100, random_state=seed, n_jobs=1).fit(X[:, conf], y).feature_importances_
            conf = conf[np.argsort(-imp)[:k]]
        return np.sort(conf)
    if name == 'Genetic Algorithm':
        return genetic(X, y, rng=rng, seed=seed)[0]
    if name == 'Particle Swarm Optimization':
        return binary_pso(X, y, [], chaotic=False, domain_aware=False, rng=rng, seed=seed)[0]
    raise ValueError(name)
