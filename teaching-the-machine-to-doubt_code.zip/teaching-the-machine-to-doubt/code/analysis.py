"""Compute every results table from the saved outputs. Writes CSVs and one Excel workbook."""
import json, itertools
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import (f1_score, precision_recall_fscore_support, roc_auc_score, average_precision_score,
                             confusion_matrix, roc_curve)
from sklearn.ensemble import RandomForestClassifier
from common import load, outer_folds, Prep, SEED, OUT, V

df, meta = load(); F = meta['features']; y = df['y'].values; N = len(y)
GROUPS = meta.get('groups', {'grp_sex': ['Girl', 'Boy'], 'grp_language': ['Always/almost always', 'Sometimes/never'], 'grp_home_resources': ['Few', 'Some', 'Many']})
CONT = meta.get('cont_target', 'PV1')
TIMSS = 'groups' not in meta
folds = outer_folds(y)
CLS = ['At-Risk', 'Moderate', 'High']
T = {}


def r(x, d=3):
    return None if x is None or (isinstance(x, float) and np.isnan(x)) else round(float(x), d)


# ---------------- helpers ----------------
def kuncheva(a, b, n):
    a, b = set(a), set(b); ka, kb = len(a), len(b); rr = len(a & b)
    if ka == kb:                      # Kuncheva (2007), equal subset sizes
        return (rr - ka * ka / n) / (ka - ka * ka / n)
    num = rr - ka * kb / n; den = min(ka, kb) - max(0, ka + kb - n)   # Lustgarten et al. (2009) extension
    return num / den if den else 1.0


def jaccard(a, b):
    a, b = set(a), set(b); return len(a & b) / len(a | b)


def ece_mce(p, yy, B=15):
    c = p.max(1); pr = p.argmax(1); e = 0; m_ = 0
    for i in range(B):
        m = (c > i / B) & (c <= (i + 1) / B)
        if m.any():
            g = abs((pr[m] == yy[m]).mean() - c[m].mean()); e += m.mean() * g; m_ = max(m_, g)
    return e, m_


def brier(p, yy):
    return ((p - np.eye(3)[yy]) ** 2).sum(1).mean()


def nll(p, yy):
    return -np.log(np.clip(p[np.arange(len(yy)), yy], 1e-12, 1)).mean()


def fold_acc(p, yy):
    return np.array([(p[te].argmax(1) == yy[te]).mean() for _, te in folds])


def corrected_t(a, b):
    d = a - b; n_te = N / V; n_tr = N - n_te
    s2 = d.var(ddof=1)
    t = d.mean() / np.sqrt((1 / V + n_te / n_tr) * s2) if s2 > 0 else np.inf
    return t, 2 * stats.t.sf(abs(t), V - 1)


def wilson(k, n, z=1.96):
    p = k / n; d = 1 + z * z / n; c = (p + z * z / (2 * n)) / d; h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return c - h, c + h


def cohen_d(a, b):
    na, nb = len(a), len(b); sp = np.sqrt(((na - 1) * a.var(ddof=1) + (nb - 1) * b.var(ddof=1)) / (na + nb - 2))
    return (a.mean() - b.mean()) / sp


def fpr_at_tpr(err, u, tpr=0.95):
    f, t, _ = roc_curve(err, u); return f[np.searchsorted(t, tpr)]


# ---------------- Table: sample and KSA by subgroup ----------------
def t_sample():
    rows = [dict(item='Students in file', value=meta['screen']['returned'])]
    if TIMSS:
        rows.append(dict(item='Excluded: more than 10% of questionnaire items missing', value=meta['screen']['excluded_gt10pct_missing_items']))
    rows.append(dict(item='Analytic sample', value=N))
    for c, n in zip(range(3), CLS):
        rows.append(dict(item=f'Band {n}', value=f'{(y == c).sum()} ({(y == c).mean() * 100:.1f}%)'))
    if TIMSS:
        rows.append(dict(item='Cut-offs on 1st plausible value (18th / 68th percentile)', value=f"{meta['cuts']['PV1'][0]:.1f} / {meta['cuts']['PV1'][1]:.1f}"))
    else:
        rows.append(dict(item='Target', value=meta['target_desc']))
    for g in GROUPS:
        for k_, n in df[g].value_counts().items(): rows.append(dict(item=f'{g[4:]}: {k_}', value=f'{n} ({n / N * 100:.1f}%)'))
    if 'age' in df:
        rows.append(dict(item='Age, mean (SD)', value=f"{df['age'].mean():.2f} ({df['age'].std():.2f})"))
    rows.append(dict(item='Candidate features (Knowledge / Skill / Attitude / Context)',
                     value='/'.join(str(sum(meta['domain_of'][f] == d for f in F)) for d in ['Knowledge', 'Skill', 'Attitude', 'Context'])))
    T['V2_sample'] = pd.DataFrame(rows)
    if not TIMSS:
        return
    out = []
    for g, order in GROUPS.items():
        for cat in order:
            s = df[df[g] == cat]
            row = dict(group=g[4:], category=cat, n=len(s))
            for d in ['Knowledge', 'Skill', 'Attitude']:
                row[d] = f"{s['score_' + d].mean():.2f} ({s['score_' + d].std():.2f})"
            out.append(row)
        tests = []
        for d in ['Knowledge', 'Skill', 'Attitude']:
            groups = [df.loc[df[g] == c_, 'score_' + d].dropna().values for c_ in order]
            if len(order) == 2:
                t_, p_ = stats.ttest_ind(groups[0], groups[1], equal_var=False)
                tests.append(f"{d}: t = {t_:.2f}, p = {p_:.3g}, d = {cohen_d(groups[1], groups[0]):.2f}")
            else:
                f_, p_ = stats.f_oneway(*groups); allv = np.concatenate(groups)
                ssb = sum(len(x) * (x.mean() - allv.mean()) ** 2 for x in groups); sst = ((allv - allv.mean()) ** 2).sum()
                tests.append(f"{d}: F = {f_:.2f}, p = {p_:.3g}, eta2 = {ssb / sst:.3f}")
        out.append(dict(group=g[4:], category='Test', n=None, Knowledge=tests[0], Skill=tests[1], Attitude=tests[2]))
    T['V3_ksa_by_subgroup'] = pd.DataFrame(out)


# ---------------- Selection tables ----------------
def fs_rows(res, name):
    subs = [r_['subset'] for r_ in res]; L = len(F)
    pairs = list(itertools.combinations(range(V), 2))
    ku = np.mean([kuncheva(subs[i], subs[j], L) for i, j in pairs])
    ja = np.mean([jaccard(subs[i], subs[j]) for i, j in pairs])
    di = np.mean([2 * len(set(subs[i]) & set(subs[j])) / (len(subs[i]) + len(subs[j])) for i, j in pairs])
    acc = np.array([r_['acc'] for r_ in res]); mf = np.array([r_['macro_f1'] for r_ in res])
    sizes = np.array([r_['size'] for r_ in res])
    conv = [r_['conv'] for r_ in res if r_.get('conv') is not None]
    return dict(method=name, subset_size=f'{sizes.mean():.1f} ({sizes.std(ddof=1):.1f})', kuncheva=r(ku), jaccard=r(ja), dice=r(di),
                accuracy=f'{acc.mean():.3f} ± {acc.std(ddof=1):.3f}', macro_f1=f'{mf.mean():.3f} ± {mf.std(ddof=1):.3f}',
                acc_mean=acc.mean(), conv=np.mean(conv) if conv else None,
                seconds_per_fold=np.mean([r_['seconds'] for r_ in res]), _acc=acc)


def t_selection():
    base = json.load(open(f'{OUT}/fs_baselines.json')); main = json.load(open(f'{OUT}/fs_main.json'))
    rows = [fs_rows(v_, k_) for k_, v_ in base.items()] + [fs_rows(main['DA-CPSO-RF'], 'DA-CPSO-RF (proposed)')]
    d = pd.DataFrame(rows)
    T['V5_selection_stability'] = d.drop(columns=['_acc', 'conv']).round(3)
    # ablation of search components
    try: pso = json.load(open(f'{OUT}/fs_pso.json'))['PSO']
    except FileNotFoundError: pso = base['Particle Swarm Optimization']
    abl = [('PSO', pso, 'No', 'No'), ('CPSO', main['CPSO'], 'Yes', 'No'),
           ('DA-PSO', main['DA-PSO'], 'No', 'Yes'), ('DA-CPSO-RF (proposed)', main['DA-CPSO-RF'], 'Yes', 'Yes')]
    ar = []
    for n, res, c, dd in abl:
        x = fs_rows(res, n)
        ar.append(dict(variant=n, chaotic_init=c, domain_aware=dd, accuracy=x['accuracy'], macro_f1=x['macro_f1'],
                       kuncheva=x['kuncheva'], convergence_iteration=r(x['conv'], 1), seconds_per_fold=r(x['seconds_per_fold'], 1)))
    T['V7_search_ablation'] = pd.DataFrame(ar)
    # consensus features
    subs = [r_['subset'] for r_ in main['DA-CPSO-RF']]
    freq = pd.Series([f for s in subs for f in s]).value_counts()
    imp = {f: [] for f in F}
    for v, (tr, te) in enumerate(folds):
        prep = Prep(F, meta['ordinal']).fit(df.iloc[tr]); X = prep.transform(df.iloc[tr])
        fi = [F.index(s) for s in subs[v]]
        rf = RandomForestClassifier(100, random_state=SEED, n_jobs=2).fit(X[:, fi], y[tr])
        for s, w in zip(subs[v], rf.feature_importances_): imp[s].append(w)
    cons = []
    for f, c in freq.items():
        if c >= 3:
            rho = stats.spearmanr(df[f], df[CONT] if CONT else df['y'], nan_policy='omit')[0]
            cons.append(dict(feature=f, label=meta['labels'][f], domain=meta['domain_of'][f], frequency=f'{c}/5',
                             importance=f'{np.mean(imp[f]):.4f} ({np.std(imp[f], ddof=1) if len(imp[f]) > 1 else 0:.4f})', spearman_rho_with_PV1=r(rho, 2)))
    T['V6_consensus_features'] = pd.DataFrame(cons)
    # sensitivity
    sens = {}
    for g in ['sens0', 'sens1', 'vmax']:
        try: sens.update(json.load(open(f'{OUT}/fs_{g}.json')))
        except FileNotFoundError: pass
    ref = fs_rows(main['DA-CPSO-RF'], 'ref')
    srows = [dict(parameter='Reference (Table 4 settings)', value='', accuracy=ref['accuracy'], kuncheva=ref['kuncheva'],
                  delta_accuracy=0.0, convergence_iteration=r(ref['conv'], 1))]
    for k_, res in sens.items():
        x = fs_rows(res, k_); p_, v_ = k_[5:].split('=')
        srows.append(dict(parameter=p_, value=v_, accuracy=x['accuracy'], kuncheva=x['kuncheva'],
                          delta_accuracy=r(x['acc_mean'] - ref['acc_mean']), convergence_iteration=r(x['conv'], 1)))
    T['V8_sensitivity'] = pd.DataFrame(srows)
    return d


# ---------------- Stage 3 tables ----------------
def load_s3(tag):
    z = np.load(f'{OUT}/stage3_{tag}.npz'); out = {}
    for k_ in z.files:
        m, key = k_.split('|'); out.setdefault(m, {})[key] = z[k_]
    return out, json.load(open(f'{OUT}/stage3_{tag}_meta.json'))


def perf(p, yy):
    pred = p.argmax(1); e, m_ = ece_mce(p, yy)
    return dict(accuracy=(pred == yy).mean(), macro_f1=f1_score(yy, pred, average='macro'),
                at_risk_recall=((pred == 0) & (yy == 0)).sum() / (yy == 0).sum(),
                auroc=roc_auc_score(yy, p, multi_class='ovr', average='macro'),
                ece=e, mce=m_, brier=brier(p, yy), nll=nll(p, yy), sharpness=p.max(1).mean())


def t_stage3():
    S, M = load_s3('y_DA-CPSO-RF'); md = pd.DataFrame(M)
    methods = ['Softmax MLP', 'MC Dropout (50 passes)', 'Temperature Scaling', 'Deep Ensemble (3 models)', 'KSA-EADE']
    ke = S['KSA-EADE']; pf = ke['p_fused']; acc_k = fold_acc(pf, y)
    rows, cal, cal_u = [], [], []
    for m in ['RF'] + methods:
        for fused in ([True] if m == 'RF' else [False, True]):
            p = S[m]['p_fused' if fused else 'p']; x = perf(p, y); fa = fold_acc(p, y)
            t_, pv = corrected_t(acc_k, fa) if m != 'KSA-EADE' or not fused else (None, None)
            rho = md[md.method == m]['rho'].dropna()
            name = m if m == 'RF' else f"{m} {'+ RF fusion' if fused else '(no fusion)'}"
            rows.append(dict(model=name, accuracy=f'{x["accuracy"]:.3f} ± {fa.std(ddof=1):.3f}', macro_f1=r(x['macro_f1']),
                             at_risk_recall=r(x['at_risk_recall']), class_auroc=r(x['auroc']),
                             rho_per_fold=','.join(f'{q:g}' for q in rho) if fused and m != 'RF' else '',
                             t_vs_KSA_EADE_fused=r(t_, 2), p_value=r(pv, 3)))
            (cal if fused else cal_u).append(dict(model=name, ECE=r(x['ece']), MCE=r(x['mce']), Brier=r(x['brier']), NLL=r(x['nll']), sharpness=r(x['sharpness'])))
    T['V9_model_comparison'] = pd.DataFrame(rows)
    T['V11_calibration_fused'] = pd.DataFrame(cal); T['V11b_calibration_unfused'] = pd.DataFrame(cal_u)
    # per-class for KSA-EADE fused
    pred = pf.argmax(1); P_, R_, F_, Sup = precision_recall_fscore_support(y, pred)
    cm = confusion_matrix(y, pred)
    pc = []
    for c in range(3):
        tn = cm.sum() - cm[c].sum() - cm[:, c].sum() + cm[c, c]; spec = tn / (tn + cm[:, c].sum() - cm[c, c])
        pc.append(dict(cls=CLS[c], support=int(Sup[c]), precision=r(P_[c]), recall=r(R_[c]), f1=r(F_[c]), specificity=r(spec),
                       auroc=r(roc_auc_score(y == c, pf[:, c]))))
    pc.append(dict(cls='Macro average', support=N, precision=r(P_.mean()), recall=r(R_.mean()), f1=r(F_.mean())))
    w = Sup / N
    pc.append(dict(cls='Weighted average', support=N, precision=r((P_ * w).sum()), recall=r((R_ * w).sum()), f1=r((F_ * w).sum())))
    T['V10_per_class'] = pd.DataFrame(pc)
    T['V10b_confusion_matrix'] = pd.DataFrame(cm, index=[f'true {c}' for c in CLS], columns=[f'pred {c}' for c in CLS]).reset_index()
    # uncertainty by outcome
    err = pred != y
    ur = []
    for name_, mask in [('Correct', ~err), ('Incorrect', err)]:
        ur.append(dict(outcome=name_, n=int(mask.sum()), **{k_: f"{ke[k_][mask].mean():.3f} ({ke[k_][mask].std(ddof=1):.3f})" for k_ in ['epistemic', 'aleatoric', 'total', 'vacuity']}))
    tt = {k_: stats.ttest_ind(ke[k_][err], ke[k_][~err], equal_var=False) for k_ in ['epistemic', 'aleatoric', 'total', 'vacuity']}
    ur.append(dict(outcome="Welch's t (p)", **{k_: f'{v_[0]:.2f} ({v_[1]:.2g})' for k_, v_ in tt.items()}))
    ur.append(dict(outcome="Cohen's d", **{k_: f'{cohen_d(ke[k_][err], ke[k_][~err]):.2f}' for k_ in tt}))
    T['V12_uncertainty_by_outcome'] = pd.DataFrame(ur)
    md_ = []
    for k_, lab in [('total', 'Total uncertainty (entropy of Dirichlet mean)'), ('vacuity', 'Vacuity (C/S)'),
                    ('epistemic', 'Epistemic (mutual information)'), ('aleatoric', 'Aleatoric (expected entropy)')]:
        md_.append(dict(measure=lab, AUROC=r(roc_auc_score(err, ke[k_])), AUPRC=r(average_precision_score(err, ke[k_])), FPR_at_95TPR=r(fpr_at_tpr(err, ke[k_]))))
    mp = 1 - pf.max(1)
    md_.append(dict(measure='Maximum-probability baseline (1 - max fused prob.)', AUROC=r(roc_auc_score(err, mp)), AUPRC=r(average_precision_score(err, mp)), FPR_at_95TPR=r(fpr_at_tpr(err, mp))))
    md_.append(dict(measure=f'Error base rate', AUROC=None, AUPRC=r(err.mean())))
    T['V13_misclassification_detection'] = pd.DataFrame(md_)
    # selective prediction
    order = np.argsort(ke['total']); sr = []
    for cov in [1.0, 0.9, 0.8, 0.7, 0.6, 0.5]:
        keep = order[:int(round(cov * N))]; yk, pk = y[keep], pred[keep]
        sr.append(dict(coverage=cov, n_retained=len(keep), accuracy=r((pk == yk).mean()),
                       at_risk_recall=r(((pk == 0) & (yk == 0)).sum() / max((yk == 0).sum(), 1)), at_risk_retained=int((yk == 0).sum()),
                       selective_risk=r(1 - (pk == yk).mean())))
    T['V14_selective_prediction'] = pd.DataFrame(sr)
    # architecture ablation (all with the same RF fusion step)
    ab = []
    for m, lab in [('KSA-EADE', 'Full KSA-EADE'), ('Softmax MLP', '- Evidential head (softmax)'),
                   ('- Attention (mean pooling)', '- Attention (mean pooling)'), ('- KSA partitioning (shared block)', '- KSA partitioning (shared block)')]:
        p = S[m]['p_fused']; x = perf(p, y); e_ = p.argmax(1) != y; fa = fold_acc(p, y)
        ab.append(dict(variant=lab, accuracy=f'{x["accuracy"]:.3f} ± {fa.std(ddof=1):.3f}', macro_f1=r(x['macro_f1']), class_auroc=r(x['auroc']),
                       err_det_auroc=r(roc_auc_score(e_, S[m]['total'])), ECE=r(x['ece'])))
    p = ke['p']; x = perf(p, y); e_ = p.argmax(1) != y; fa = fold_acc(p, y)
    ab.append(dict(variant='- RF fusion (rho = 0)', accuracy=f'{x["accuracy"]:.3f} ± {fa.std(ddof=1):.3f}', macro_f1=r(x['macro_f1']), class_auroc=r(x['auroc']),
                   err_det_auroc=r(roc_auc_score(e_, ke['total'])), ECE=r(x['ece'])))
    T['V15_architecture_ablation'] = pd.DataFrame(ab)
    # cumulative pipeline
    p_all = np.zeros((N, 3))
    for v, (tr, te) in enumerate(folds):
        prep = Prep(F, meta['ordinal']).fit(df.iloc[tr]); X = prep.transform(df)
        p_all[te] = RandomForestClassifier(100, random_state=SEED, n_jobs=2).fit(X[tr], y[tr]).predict_proba(X[te])
    cu = []
    ks = np.mean([r_['size'] for r_ in json.load(open(f'{OUT}/fs_main.json'))['DA-CPSO-RF']]); ksel = f'{ks:.1f} selected features (mean)' if ks != 20 else '20 selected features'
    for lab, fr, clf, p in [('Stage 1 output: all candidate features', f'{len(F)} domain-tagged features', 'Random Forest', p_all),
                            ('+ Stage 2: DA-CPSO-RF selection', ksel, 'Random Forest', S['RF']['p']),
                            ('+ Stage 3: KSA-EADE network (no fusion)', ksel, 'KSA-EADE', ke['p']),
                            ('+ RF fusion: full pipeline', ksel, 'KSA-EADE + RF', pf)]:
        x = perf(p, y); fa = fold_acc(p, y)
        cu.append(dict(configuration=lab, features=fr, classifier=clf, accuracy=f'{x["accuracy"]:.3f} ± {fa.std(ddof=1):.3f}',
                       macro_f1=r(x['macro_f1']), at_risk_recall=r(x['at_risk_recall']), ECE=r(x['ece'])))
    T['V16_cumulative_pipeline'] = pd.DataFrame(cu)
    # subgroups
    sg = []; acc_all = (pred == y).mean()
    for g, order_ in GROUPS.items():
        for cat in order_:
            m = (df[g] == cat).values; yk, pk, pp = y[m], pred[m], pf[m]
            k_ = (pk == yk).sum(); lo, hi = wilson(k_, m.sum())
            neg = yk != 0
            sg.append(dict(group=g[4:], subgroup=cat, n=int(m.sum()), accuracy=f'{k_ / m.sum():.3f} [{lo:.3f}, {hi:.3f}]',
                           at_risk_n=int((yk == 0).sum()), at_risk_recall=r(((pk == 0) & (yk == 0)).sum() / max((yk == 0).sum(), 1)),
                           at_risk_FPR=r(((pk == 0) & neg).sum() / neg.sum()), macro_f1=r(f1_score(yk, pk, average='macro')),
                           ECE=r(ece_mce(pp, yk)[0]), delta_accuracy=r(k_ / m.sum() - acc_all)))
    T['V17_subgroups'] = pd.DataFrame(sg)
    # cost
    cost = []
    for m in methods + ['RF']:
        d_ = md[md.method == m]
        cost.append(dict(model=m, parameters=r(d_['params'].mean(), 0) if 'params' in d_ and d_['params'].notna().any() else None,
                         train_seconds_per_fold=r(d_['train_seconds'].mean(), 2),
                         latency_ms_per_sample=f"{d_['latency_ms'].mean():.4f} ± {d_['latency_sd'].mean():.4f}" if d_['latency_ms'].notna().any() else None,
                         multiply_accumulates=r(d_['macs'].mean(), 0) if 'macs' in d_ and d_['macs'].notna().any() else None))
    T['V19_cost'] = pd.DataFrame(cost)
    # attention weights
    at = []
    for b_ in ['Knowledge', 'Skill', 'Attitude', 'Context']:
        k_ = 'att_' + b_
        if k_ in ke:
            row = dict(domain=b_, overall=r(np.nanmean(ke[k_])))
            for c in range(3): row[CLS[c]] = r(np.nanmean(ke[k_][y == c]))
            at.append(row)
    T['V20_attention_weights'] = pd.DataFrame(at)


def t_pv():
    rows = []
    for i in range(1, 6):
        tag = 'y_DA-CPSO-RF' if i == 1 else f'y_PV{i}_DA-CPSO-RF'
        lab = 'y' if i == 1 else f'y_PV{i}'
        try: S, _ = load_s3(tag)
        except FileNotFoundError: continue
        yy = df[lab].values
        for m, key, nm in [('RF', 'p', 'Random Forest'), ('KSA-EADE', 'p_fused', 'KSA-EADE + RF fusion')]:
            p = S[m][key]; x = perf(p, yy); e_ = p.argmax(1) != yy
            rows.append(dict(plausible_value=i, model=nm, accuracy=r(x['accuracy']), macro_f1=r(x['macro_f1']),
                             at_risk_recall=r(x['at_risk_recall']), ECE=r(x['ece']),
                             err_det_auroc=r(roc_auc_score(e_, S['KSA-EADE']['total'])) if m == 'KSA-EADE' else None))
    d = pd.DataFrame(rows)
    if len(d):
        for nm in d.model.unique():
            s = d[d.model == nm]
            d = pd.concat([d, pd.DataFrame([dict(plausible_value='Mean (SD)', model=nm,
                **{c: f"{s[c].mean():.3f} ({s[c].std(ddof=1):.3f})" for c in ['accuracy', 'macro_f1', 'at_risk_recall', 'ECE']})])])
    T['V18_plausible_values'] = d


if __name__ == '__main__':
    T['V1_stage1_measurement'] = pd.read_csv(f'{OUT}/T_stage1_measurement.csv')
    T['V4_stage1_loadings'] = pd.read_csv(f'{OUT}/T_stage1_loadings.csv')
    t_sample(); t_selection(); t_stage3()
    if TIMSS: t_pv()
    with pd.ExcelWriter(f'{OUT}/TIMSS_results_tables.xlsx') as w:
        for k_ in sorted(T, key=lambda s: (int(''.join(ch for ch in s.split('_')[0][1:] if ch.isdigit())), s)):
            T[k_].to_excel(w, sheet_name=k_[:31], index=False); T[k_].to_csv(f'{OUT}/{k_}.csv', index=False)
    for k_ in T: print('\n==', k_); print(T[k_].to_string(index=False)[:3000])
