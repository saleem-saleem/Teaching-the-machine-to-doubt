#!/bin/sh
# Run every experiment for one dataset.  Usage: sh run_dataset.sh <timss|dropout|por|mat|xapi>
set -e
D=$1
cd "$(dirname "$0")"
if [ "$D" = "timss" ]; then python3 data.py; else python3 data_pub.py "$D"; fi
DATASET=$D python3 run_fs.py main          # DA-CPSO-RF and the search ablations
DATASET=$D python3 run_stage3.py y DA-CPSO-RF   # KSA-EADE, baselines and network ablations
DATASET=$D python3 run_fs.py baselines     # ten baseline selectors
DATASET=$D python3 run_fs.py pso           # standard PSO
DATASET=$D python3 run_fs.py sens0         # sensitivity grid (part 1)
DATASET=$D python3 run_fs.py sens1         # sensitivity grid (part 2)
DATASET=$D python3 run_fs.py vmax          # velocity-limit sensitivity
if [ "$D" = "timss" ]; then
  for pv in 2 3 4 5; do DATASET=timss python3 run_stage3.py y_PV$pv DA-CPSO-RF; done   # plausible-value robustness
fi
DATASET=$D python3 analysis.py             # result tables V1-V20
DATASET=$D python3 verify.py               # arithmetic checks
