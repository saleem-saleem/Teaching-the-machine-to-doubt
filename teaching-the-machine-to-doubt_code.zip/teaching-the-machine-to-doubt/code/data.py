"""Stage 1 on TIMSS 2023 Grade 8 Singapore: screening, KSA mapping, measurement checks, target bands."""
from paths import CODE, DATA, RES
import json
import numpy as np
import pandas as pd
import pyreadstat

SRC = f'{DATA}/timss/bsgsgpm8.sav'
OUT = f'{RES}/out_timss'

# ---- item map: (variable, short label, reverse-to-positive?) ----
# TIMSS agree items: 1 = agree a lot ... 4 = disagree a lot.  We recode so that higher = more positive.
K_ITEMS = [('BSBM22A', 'Usually do well in mathematics', False),
           ('BSBM22B', 'Mathematics harder for me than for others', True),
           ('BSBM22C', 'Mathematics is not one of my strengths', True),
           ('BSBM22D', 'Mathematics is easy', False),
           ('BSBM22G', 'Mathematics is harder for me than any other subject', True),
           ('BSBM22H', 'Mathematics makes me confused', True)]
S_ITEMS = [('BSBM22E', 'Good at working out difficult problems', False),
           ('BSBM22F', 'Good at explaining mathematics', False),
           ('BSBG13A', 'Can write text on a computer', False),
           ('BSBG13B', 'Can create presentations', False),
           ('BSBG13C', 'Can create graphs on a computer', False),
           ('BSBG13D', 'Can find information online', False),
           ('BSBG13E', 'Can tell if a website is trustworthy', False),
           ('BSBG13F', 'Can learn new things on a computer', False),
           ('BSBG13G', 'Can help friends and family with computers', False),
           ('BSBG12A', 'Uses internet to access textbooks', 'freq'),
           ('BSBG12B', 'Uses internet to access assignments', 'freq'),
           ('BSBG12C', 'Uses internet to collaborate with classmates', 'freq'),
           ('BSBG12D', 'Uses internet to ask teacher questions', 'freq'),
           ('BSBG12E', 'Uses internet to find information for mathematics or science', 'freq')]
A_ITEMS = [('BSBM19A', 'Enjoy learning mathematics', False),
           ('BSBM19B', 'Wish I did not have to study mathematics', True),
           ('BSBM19C', 'Mathematics is boring', True),
           ('BSBM19D', 'Learn many interesting things in mathematics', False),
           ('BSBM19E', 'Like mathematics', False),
           ('BSBM19F', 'Like any schoolwork that involves numbers', False),
           ('BSBM19G', 'Like to solve mathematics problems', False),
           ('BSBM19H', 'Look forward to mathematics class', False),
           ('BSBM19I', 'Mathematics is one of my favourite subjects', False),
           ('BSBM23A', 'Learning mathematics will help me in daily life', False),
           ('BSBM23B', 'Need mathematics to learn other subjects', False),
           ('BSBM23C', 'Need mathematics to get into university', False),
           ('BSBM23D', 'Need mathematics to get the job I want', False),
           ('BSBM23E', 'Would like a job involving mathematics', False),
           ('BSBM23F', 'Mathematics helps to get ahead in the world', False),
           ('BSBM23G', 'Mathematics gives more job opportunities', False),
           ('BSBM23I', 'Important to do well in mathematics', False)]
DOMAINS = {'Knowledge': K_ITEMS, 'Skill': S_ITEMS, 'Attitude': A_ITEMS}


def recode_item(x, rev):
    if rev == 'freq':          # 1 = weekly ... 3 = never  ->  higher = more frequent
        return 4 - x
    x = 5 - x                  # higher = more agreement
    return 5 - x if rev else x  # negatively worded: higher = less agreement = more positive


def kmo(X):
    R = np.corrcoef(X, rowvar=False); Ri = np.linalg.inv(R)
    Q = -Ri / np.sqrt(np.outer(np.diag(Ri), np.diag(Ri)))
    np.fill_diagonal(R, 0); np.fill_diagonal(Q, 0)
    return (R ** 2).sum() / ((R ** 2).sum() + (Q ** 2).sum())


def bartlett(X):
    n, p = X.shape; R = np.corrcoef(X, rowvar=False)
    chi2 = -(n - 1 - (2 * p + 5) / 6) * np.log(np.linalg.det(R))
    from scipy.stats import chi2 as C
    df = p * (p - 1) / 2
    return chi2, df, C.sf(chi2, df)


def varimax(L, gamma=1.0, it=100, tol=1e-6):
    p, k = L.shape; Rm = np.eye(k); d = 0
    for _ in range(it):
        Lam = L @ Rm
        u, s, vh = np.linalg.svd(L.T @ (Lam ** 3 - (gamma / p) * Lam @ np.diag(np.diag(Lam.T @ Lam))))
        Rm = u @ vh; d_old, d = d, s.sum()
        if d_old != 0 and d / d_old < 1 + tol: break
    return L @ Rm


def cronbach(X):
    p = X.shape[1]
    return p / (p - 1) * (1 - X.var(axis=0, ddof=1).sum() / X.sum(axis=1).var(ddof=1))


def build():
    raw, meta = pyreadstat.read_sav(SRC)
    df = pd.DataFrame({'IDSCHOOL': raw['IDSCHOOL'], 'IDSTUD': raw['IDSTUD']})
    items = []
    for dom, lst in DOMAINS.items():
        for v, lab, rev in lst:
            df[v] = recode_item(raw[v], rev); items.append((v, lab, dom))
    # ---- context (demographic / home) block ----
    ctx = {}
    ctx['boy'] = (raw['ITSEX'] == 2).astype(float)
    ctx['age'] = raw['BSDAGE']
    ctx['test_language_at_home'] = 5 - raw['BSBG03']
    ctx['books_at_home'] = raw['BSBG04']
    for c, n in zip('ABCDEF', ['own_computer', 'shared_computer', 'smartphone', 'internet', 'study_desk', 'own_room']):
        ctx['has_' + n] = (raw['BSBG05' + c] == 1).astype(float).where(raw['BSBG05' + c].notna())
    pe = raw[['BSBG06A', 'BSBG06B']].where(raw[['BSBG06A', 'BSBG06B']] <= 7)
    ctx['parent_education_max'] = pe.max(axis=1)
    ctx['parent_education_unknown'] = pe.isna().all(axis=1).astype(float)
    ctx['educational_expectation'] = raw['BSBG07']
    ctx['born_in_country'] = (raw['BSBG09A'] == 1).astype(float).where(raw['BSBG09A'].notna())
    ctx['rarely_absent'] = raw['BSBG10']
    ctx['rarely_tired'] = raw['BSBG11A']
    ctx['rarely_hungry'] = raw['BSBG11B']
    for k, v in ctx.items(): df[k] = v
    # grouping variables for subgroup analyses (not model inputs)
    df['grp_sex'] = raw['ITSEX'].map({1.0: 'Girl', 2.0: 'Boy'})
    df['grp_home_resources'] = raw['BSDGHER'].map({1.0: 'Many', 2.0: 'Some', 3.0: 'Few'})
    df['grp_language'] = np.where(raw['BSBG03'] <= 2, 'Always/almost always', np.where(raw['BSBG03'] >= 3, 'Sometimes/never', None))
    for i in range(1, 6): df[f'PV{i}'] = raw[f'BSMMAT0{i}']
    df['TOTWGT'] = raw['TOTWGT']

    item_vars = [v for v, _, _ in items]
    n0 = len(df)
    miss = df[item_vars].isna().sum(axis=1)
    keep = miss <= 0.10 * len(item_vars)
    screen = {'returned': int(n0), 'excluded_gt10pct_missing_items': int((~keep).sum())}
    df = df[keep].reset_index(drop=True)
    screen['analytic'] = int(len(df))

    # ---- Stage 1 measurement analysis (label-free, once, complete cases per domain) ----
    stage1, loadings, retained = [], [], {}
    for dom, lst in DOMAINS.items():
        cols = [v for v, _, _ in lst]
        X = df[cols].dropna().values
        R = np.corrcoef(X, rowvar=False)
        w, V = np.linalg.eigh(R); o = np.argsort(w)[::-1]; w, V = w[o], V[:, o]
        r = int((w > 1).sum())
        L = V[:, :r] * np.sqrt(w[:r])
        Lr = varimax(L) if r > 1 else L
        Lr = Lr * np.sign(Lr.sum(axis=0))
        maxl = np.abs(Lr).max(axis=1)
        keepi = [c for c, l in zip(cols, maxl) if l >= 0.40]
        retained[dom] = keepi
        chi2, dfb, pb = bartlett(X)
        stage1.append(dict(domain=dom, items=len(cols), n_complete=len(X), KMO=kmo(X), bartlett_chi2=chi2,
                           bartlett_df=dfb, bartlett_p=pb, factors_retained=r,
                           variance_explained=w[:r].sum() / len(cols), alpha=cronbach(X),
                           items_retained=len(keepi), eigenvalues=';'.join(f'{x:.2f}' for x in w[:max(r, 3)])))
        for j, c in enumerate(cols):
            lab = [l for v, l, _ in lst if v == c][0]
            loadings.append(dict(domain=dom, item=c, label=lab, **{f'F{f+1}': Lr[j, f] for f in range(r)},
                                 max_abs_loading=maxl[j], retained=maxl[j] >= 0.40))
    # domain competency scores on the 1-4 scale (retained items, mean of available)
    for dom in DOMAINS:
        df['score_' + dom] = df[retained[dom]].mean(axis=1)

    # ---- target: 3 bands from PV1 at 18th / 68th percentiles ----
    c1, c2 = np.percentile(df['PV1'], [18, 68])
    df['y'] = np.digitize(df['PV1'], [c1, c2])        # 0 At-Risk, 1 Moderate, 2 High
    cuts = {f'PV{i}': list(np.percentile(df[f'PV{i}'], [18, 68])) for i in range(1, 6)}
    for i in range(2, 6):
        a, b = cuts[f'PV{i}']; df[f'y_PV{i}'] = np.digitize(df[f'PV{i}'], [a, b])

    feat_items = [v for d in DOMAINS for v in retained[d]]
    features = feat_items + list(ctx.keys())
    domain_of = {v: d for v, _, d in items if v in feat_items}
    domain_of.update({k: 'Context' for k in ctx})
    labels = {v: l for v, l, _ in items}
    labels.update({k: k.replace('_', ' ').capitalize() for k in ctx})
    df.to_csv(f'{OUT}/timss_sgp_analytic.csv', index=False)
    pd.DataFrame(stage1).to_csv(f'{OUT}/T_stage1_measurement.csv', index=False)
    pd.DataFrame(loadings).to_csv(f'{OUT}/T_stage1_loadings.csv', index=False)
    json.dump(dict(features=features, domain_of=domain_of, labels=labels, screen=screen, cuts=cuts,
                   retained=retained, ordinal=feat_items, binary=[k for k in ctx if k.startswith(('has_', 'boy', 'born', 'parent_education_unknown'))]),
              open(f'{OUT}/meta.json', 'w'), indent=1)
    print(screen); print(pd.DataFrame(stage1).round(3).to_string())
    print('features', len(features), {d: sum(1 for f in features if domain_of[f] == d) for d in ['Knowledge', 'Skill', 'Attitude', 'Context']})
    print('class counts', df['y'].value_counts().sort_index().to_dict(), 'cuts', np.round([c1, c2], 1))


if __name__ == '__main__':
    import os; os.makedirs(OUT, exist_ok=True); build()
